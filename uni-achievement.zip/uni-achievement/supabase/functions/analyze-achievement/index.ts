import { corsHeaders } from '../_shared/cors.ts';

// 通用物体和场景识别 API 地址
const OBJECT_RECOGNITION_URL =
  'https://app-bg335ysc0we9-api-zYm4zKQoePjL-gateway.appmiaoda.com/rest/2.0/image-classify/v2/advanced_general';

// OCR高精度文字识别 API 地址
const OCR_URL =
  'https://app-bg335ysc0we9-api-eLMlJ2jB44g9-gateway.appmiaoda.com/rest/2.0/ocr/v1/accurate_basic';

// 图像内容理解 - 提交请求
const IMAGE_UNDERSTANDING_REQUEST_URL =
  'https://app-bg335ysc0we9-api-DYJwo27V85oa-gateway.appmiaoda.com/rest/2.0/image-classify/v1/image-understanding/request';

// 图像内容理解 - 获取结果
const IMAGE_UNDERSTANDING_GET_URL =
  'https://app-bg335ysc0we9-api-zYkZz8qoKDdL-gateway.appmiaoda.com/rest/2.0/image-classify/v1/image-understanding/get-result';

// 根据识别结果推断分类
function inferCategory(keywords: string[], ocrText: string): {
  category: string;
  subcategory: string | null;
  level: string | null;
} {
  const text = (keywords.join(' ') + ' ' + ocrText).toLowerCase();

  // 奖项等级判断
  let level: string | null = null;
  if (text.includes('国家') || text.includes('全国')) level = '国家级';
  else if (text.includes('省') || text.includes('市')) level = '省级';
  else if (text.includes('校') || text.includes('学校')) level = '校级';
  else if (text.includes('院') || text.includes('系') || text.includes('学院')) level = '院级';

  // 分类判断 - 拓展支持聘书/实习/证件
  if (
    text.includes('聘书') ||
    text.includes('聘任') ||
    text.includes('任命')
  ) {
    return { category: '学生工作', subcategory: '聘书', level: null };
  }

  if (
    text.includes('实习') ||
    text.includes('实训') ||
    text.includes('internship')
  ) {
    return { category: '志愿实践', subcategory: '实习经历', level };
  }

  if (
    text.includes('志愿') ||
    text.includes('义工') ||
    text.includes('公益')
  ) {
    return { category: '志愿实践', subcategory: '志愿服务', level };
  }

  if (
    text.includes('社会实践') ||
    text.includes('下乡') ||
    text.includes('调研')
  ) {
    return { category: '志愿实践', subcategory: '社会实践', level };
  }

  if (
    text.includes('论文') ||
    text.includes('发表') ||
    text.includes('期刊') ||
    text.includes('核心') ||
    text.includes('journal')
  ) {
    return { category: '学术成果', subcategory: '发表论文', level: null };
  }

  if (
    text.includes('专利') ||
    text.includes('软件著作') ||
    text.includes('软著')
  ) {
    return { category: '学术成果', subcategory: '软著/专利', level: null };
  }

  if (
    text.includes('录用') ||
    text.includes('接收函') ||
    text.includes('accept')
  ) {
    return { category: '学术成果', subcategory: '录用通知', level: null };
  }

  if (
    text.includes('竞赛') ||
    text.includes('比赛') ||
    text.includes('大赛') ||
    text.includes('挑战杯') ||
    text.includes('创新创业') ||
    text.includes('hackathon')
  ) {
    let sub = '学科竞赛';
    if (text.includes('创新') || text.includes('创业')) sub = '创新创业竞赛';
    else if (text.includes('文化') || text.includes('体育') || text.includes('艺术')) sub = '文体竞赛';
    return { category: '赛事竞赛', subcategory: sub, level };
  }

  if (
    text.includes('学生会') ||
    text.includes('团委') ||
    text.includes('班长') ||
    text.includes('干部') ||
    text.includes('任职') ||
    text.includes('学生干部')
  ) {
    return { category: '学生工作', subcategory: '任职证明', level: null };
  }

  if (
    text.includes('证件照') ||
    text.includes('一寸') ||
    text.includes('两寸') ||
    text.includes('免冠照')
  ) {
    return { category: '个人证件', subcategory: null, level: null };
  }

  if (
    text.includes('奖') ||
    text.includes('荣誉') ||
    text.includes('证书') ||
    text.includes('优秀')
  ) {
    let sub = '校级奖项';
    if (level === '国家级') sub = '国家级奖项';
    else if (level === '省级') sub = '省级奖项';
    else if (level === '院级') sub = '院级奖项';
    return { category: '荣誉奖项', subcategory: sub, level };
  }

  return { category: '其他', subcategory: null, level };
}

// 从文件名推断分类（用于PDF/文档类）
function inferCategoryFromFilename(filename: string): {
  category: string;
  subcategory: string | null;
  level: string | null;
  suggested_name: string;
} {
  const baseName = filename.replace(/\.[^.]+$/, '');
  const result = inferCategory([], baseName);
  return { ...result, suggested_name: baseName };
}

// 汉字数字映射（支持〇/零/一/二/三/四/五/六/七/八/九/十）
function convertChineseNumerals(text: string): string {
  const map: Record<string, string> = {
    '〇': '0', '零': '0', '一': '1', '二': '2', '三': '3',
    '四': '4', '五': '5', '六': '6', '七': '7', '八': '8', '九': '9',
  };
  // 先替换汉字数字为阿拉伯数字
  let result = text.replace(/[〇零一二三四五六七八九]/g, (ch) => map[ch] ?? ch);
  // 处理"十X月"/"十月"形式（如"十二月" → "12月"，"十月" → "10月"）
  result = result.replace(/十([一二三四五六七八九]?)月/g, (_, d) => `1${map[d] ?? '0'}月`);
  // 处理"X十Y日/号"（如"二十三日" → "23日"，"三十日" → "30日"）
  result = result.replace(/(\d)十(\d?)([日号年月])/g, (_, a, b, c) => `${a}${b || '0'}${c}`);
  // 处理纯"十日/号"
  result = result.replace(/十([日号])/g, '10$1');
  return result;
}

// 从OCR文本中提取日期（支持汉字日期）
function extractDate(rawText: string): string | null {
  // 先转换汉字数字
  const text = convertChineseNumerals(rawText);

  const patterns = [
    /(\d{4})年(\d{1,2})月(\d{1,2})[日号]?/,
    /(\d{4})[-.\/](\d{1,2})[-.\/](\d{1,2})/,
    /(\d{4})年(\d{1,2})月/,
    /(\d{4})[.年](\d{1,2})/,
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) {
      const year = match[1];
      const month = String(parseInt(match[2])).padStart(2, '0');
      const day = match[3] ? String(parseInt(match[3])).padStart(2, '0') : '01';
      // 基本校验
      if (parseInt(year) >= 2000 && parseInt(year) <= 2035 &&
          parseInt(month) >= 1 && parseInt(month) <= 12 &&
          parseInt(day) >= 1 && parseInt(day) <= 31) {
        return `${year}-${month}-${day}`;
      }
    }
  }
  return null;
}

// 生成命名建议
function generateName(ocrText: string, keywords: string[], description: string): string {
  const awardPatterns = [
    /([^\n，,。.]{4,30}(?:奖|荣誉|证书|认证|证明))/,
    /([^\n，,。.]{4,30}(?:竞赛|大赛|比赛|杯)(?:.*?(?:一等奖|二等奖|三等奖|优秀奖|特等奖))?)/,
    /((?:国家级|省级|校级|院级)[^\n，,。.]{4,20}奖)/,
    /([^\n，,。.]{4,20}(?:聘书|聘任|任命书))/,
    /([^\n，,。.]{4,20}(?:实习证明|实习鉴定))/,
  ];

  for (const pattern of awardPatterns) {
    const match = ocrText.match(pattern);
    if (match) {
      return match[1].trim();
    }
  }

  if (keywords.length > 0) {
    if (keywords.length > 1) {
      return `${keywords[0]}-${keywords[1]}`;
    }
    return keywords[0];
  }

  if (description && description.length > 5) {
    return description.substring(0, 20).trim() + (description.length > 20 ? '...' : '');
  }

  return `成就材料-${new Date().toISOString().slice(0, 10)}`;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// 检测是否为PDF（检查base64解码后的魔术字节）
function isPdfBase64(base64: string): boolean {
  try {
    const decoded = atob(base64.substring(0, 20));
    return decoded.startsWith('%PDF');
  } catch {
    return false;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'API密钥未配置' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const authHeader = `Bearer ${apiKey}`;
    const body = await req.json();
    const { image_base64, filename, file_type } = body;

    // 如果是PDF或文档类型，使用文件名推断，不调用图像API
    if (file_type === 'pdf' || file_type === 'word' || file_type === 'excel' ||
        (image_base64 && isPdfBase64(image_base64)) ||
        (filename && /\.(pdf|doc|docx|xls|xlsx)$/i.test(filename))) {
      const fname = filename || `文件-${new Date().toISOString().slice(0, 10)}`;
      const { category, subcategory, level, suggested_name } = inferCategoryFromFilename(fname);
      return new Response(JSON.stringify({
        suggested_name,
        suggested_category: category,
        suggested_subcategory: subcategory,
        suggested_level: level,
        suggested_date: null,
        description: `${fname} - 文档类材料，已根据文件名智能分类`,
        keywords: [],
        ocr_text: '',
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!image_base64) {
      return new Response(
        JSON.stringify({ error: '缺少图片数据' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 1. 并发调用：物体识别 + OCR文字识别
    const formBody = `image=${encodeURIComponent(image_base64)}`;

    const [objectRes, ocrRes] = await Promise.all([
      fetch(OBJECT_RECOGNITION_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-Gateway-Authorization': authHeader,
        },
        body: formBody,
      }),
      fetch(OCR_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-Gateway-Authorization': authHeader,
        },
        body: `image=${encodeURIComponent(image_base64)}&language_type=CHN_ENG&detect_direction=false`,
      }),
    ]);

    if (objectRes.status === 429 || objectRes.status === 402) {
      const errMsg = await objectRes.text();
      return new Response(
        JSON.stringify({ error: `物体识别API错误: ${errMsg}` }),
        { status: objectRes.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    if (ocrRes.status === 429 || ocrRes.status === 402) {
      const errMsg = await ocrRes.text();
      return new Response(
        JSON.stringify({ error: `OCR识别API错误: ${errMsg}` }),
        { status: ocrRes.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const objectData = await objectRes.json();
    const ocrData = await ocrRes.json();

    const keywords: string[] = (objectData.result || []).map(
      (r: { keyword: string }) => r.keyword
    );

    const ocrText: string = (ocrData.words_result || [])
      .map((w: { words: string }) => w.words)
      .join('\n');

    // 2. 并发：图像内容理解（材料描述）+ 人脸数量检测
    let description = '';
    let faceCount = 0; // 0=未知，1=单人脸，2+=多人脸

    try {
      // 同时提交两个理解任务
      const [contentReq, faceReq] = await Promise.all([
        fetch(IMAGE_UNDERSTANDING_REQUEST_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-Gateway-Authorization': authHeader },
          body: JSON.stringify({
            image: image_base64,
            question: '这是什么证书或材料？请描述其中的奖项名称、颁发单位、时间、任职信息、实习信息等关键信息。',
          }),
        }),
        fetch(IMAGE_UNDERSTANDING_REQUEST_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-Gateway-Authorization': authHeader },
          body: JSON.stringify({
            image: image_base64,
            question: '这张照片中有几个人脸？请只用数字回答，例如：1 或 2 或 3。',
          }),
        }),
      ]);

      const contentTaskId = contentReq.ok ? (await contentReq.json())?.result?.task_id : null;
      const faceTaskId = faceReq.ok ? (await faceReq.json())?.result?.task_id : null;

      // 轮询两个任务（最多4次，每次等2秒）
      let contentDone = !contentTaskId;
      let faceDone = !faceTaskId;

      for (let i = 0; i < 4 && (!contentDone || !faceDone); i++) {
        await sleep(2000);

        if (!contentDone && contentTaskId) {
          const r = await fetch(IMAGE_UNDERSTANDING_GET_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Gateway-Authorization': authHeader },
            body: JSON.stringify({ task_id: contentTaskId }),
          });
          if (r.ok) {
            const d = await r.json();
            if (d?.result?.ret_code === 0) {
              description = d?.result?.description || '';
              contentDone = true;
            } else if (d?.result?.ret_code !== 1 && d?.result?.ret_code !== 2) {
              contentDone = true;
            }
          }
        }

        if (!faceDone && faceTaskId) {
          const r = await fetch(IMAGE_UNDERSTANDING_GET_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Gateway-Authorization': authHeader },
            body: JSON.stringify({ task_id: faceTaskId }),
          });
          if (r.ok) {
            const d = await r.json();
            if (d?.result?.ret_code === 0) {
              const faceDesc: string = d?.result?.description || '';
              // 解析人脸数量：从描述中提取数字
              const numMatch = faceDesc.match(/\d+/);
              faceCount = numMatch ? parseInt(numMatch[0]) : 0;
              faceDone = true;
            } else if (d?.result?.ret_code !== 1 && d?.result?.ret_code !== 2) {
              faceDone = true;
            }
          }
        }
      }
    } catch (_e) {
      // 图像理解失败不影响主流程
    }

    // 3. 推断分类（结合OCR文本和图像描述）
    const combinedText = ocrText + ' ' + description;
    let { category, subcategory, level } = inferCategory(keywords, combinedText);

    // 3a. 人脸检测覆盖分类：单人脸→证件照，多人脸→合照
    if (faceCount === 1) {
      category = '个人证件';
      subcategory = '证件照';
    } else if (faceCount >= 2) {
      category = '合照';
      subcategory = '合照/照片';
    }

    // 4. 提取日期（支持汉字日期自动转换）
    const suggestedDate = extractDate(combinedText);

    // 5. 生成命名建议
    const suggestedName = generateName(ocrText, keywords, description);

    return new Response(JSON.stringify({
      suggested_name: suggestedName,
      suggested_category: category,
      suggested_subcategory: subcategory,
      suggested_level: level,
      suggested_date: suggestedDate,
      description,
      keywords,
      ocr_text: ocrText,
      face_count: faceCount,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('analyze-achievement error:', error);
    return new Response(
      JSON.stringify({ error: `处理失败: ${error instanceof Error ? error.message : String(error)}` }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
