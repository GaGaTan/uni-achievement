import { corsHeaders } from '../_shared/cors.ts';

// Gemini 图片生成与编辑接口
const GEMINI_URL = 'https://app-bg335ysc0we9-api-o9wN0AExZQ8a-gateway.appmiaoda.com/v1beta/models/gemini-3.1-flash-image-preview:generateContent';

// 背景颜色文本映射
const BG_COLOR_MAP: Record<string, string> = {
  white: '纯白色',
  blue: '标准蓝色（证件照专用蓝底色 #438EDB）',
  red: '标准红色（证件照专用红底色 #C63939）',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
  if (!apiKey) {
    return new Response(
      JSON.stringify({ error: 'API密钥未配置' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  try {
    const { image_base64, mime_type = 'image/jpeg', target_bg = 'white' } = await req.json();

    if (!image_base64) {
      return new Response(
        JSON.stringify({ error: '缺少图片数据' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const bgColorDesc = BG_COLOR_MAP[target_bg] || '纯白色';
    const instruction = `这是一张人物证件照。请精确识别照片中的人像轮廓（包括头发、耳朵、肩膀），然后将照片背景完全替换为${bgColorDesc}，确保人像边缘过渡自然、无杂色残留，并且人像部分保持不变。只替换背景颜色，不要改变人像的任何部分。请返回替换背景后的完整图片。`;

    const resp = await fetch(GEMINI_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Gateway-Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        contents: [{
          parts: [
            { text: instruction },
            {
              inlineData: {
                mimeType: mime_type,
                data: image_base64,
              },
            },
          ],
        }],
        generationConfig: {
          responseModalities: ['IMAGE', 'TEXT'],
        },
      }),
    });

    if (!resp.ok) {
      const errText = await resp.text();
      return new Response(
        JSON.stringify({ error: `背景替换API错误：${errText}` }),
        { status: resp.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const data = await resp.json();

    // 从响应中提取图片
    const parts = data?.candidates?.[0]?.content?.parts || [];
    let resultBase64 = '';
    let resultMimeType = 'image/png';

    for (const part of parts) {
      if (part?.inlineData?.data) {
        resultBase64 = part.inlineData.data;
        resultMimeType = part.inlineData.mimeType || 'image/png';
        break;
      }
    }

    if (!resultBase64) {
      return new Response(
        JSON.stringify({ error: '背景替换失败：未获取到处理后的图片，请使用清晰的正面证件照重试' }),
        { status: 422, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ result_base64: resultBase64, mime_type: resultMimeType }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    console.error('replace-cert-bg error:', err);
    return new Response(
      JSON.stringify({ error: `处理失败：${err instanceof Error ? err.message : String(err)}` }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
