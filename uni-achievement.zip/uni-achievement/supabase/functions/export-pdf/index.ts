import { corsHeaders } from '../_shared/cors.ts';

// 文档格式转换 - 提交请求
const DOC_CONVERT_REQUEST_URL =
  'https://app-bg335ysc0we9-api-rY7JZ6jqrneL-gateway.appmiaoda.com/rest/2.0/ocr/v1/doc_convert/request';

// 文档格式转换 - 获取结果
const DOC_CONVERT_GET_URL =
  'https://app-bg335ysc0we9-api-oYA6ZGjReooa-gateway.appmiaoda.com/rest/2.0/ocr/v1/doc_convert/get_request_result';

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'API密钥未配置' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const authHeader = `Bearer ${apiKey}`;

    // 接收图片base64列表（单张或多张，将逐一转换后返回下载链接列表）
    const { images_base64 } = await req.json() as { images_base64: string[] };

    if (!images_base64 || images_base64.length === 0) {
      return new Response(
        JSON.stringify({ error: '缺少图片数据' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 对每张图片提交转换任务
    const taskIds: string[] = [];

    for (const imageBase64 of images_base64) {
      const formBody = `image=${encodeURIComponent(imageBase64)}`;
      const submitRes = await fetch(DOC_CONVERT_REQUEST_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-Gateway-Authorization': authHeader,
        },
        body: formBody,
      });

      if (submitRes.status === 429 || submitRes.status === 402) {
        const errMsg = await submitRes.text();
        return new Response(
          JSON.stringify({ error: `文档转换API错误: ${errMsg}` }),
          { status: submitRes.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const submitData = await submitRes.json();

      if (!submitData.success) {
        return new Response(
          JSON.stringify({ error: `提交转换任务失败: ${submitData.message || '未知错误'}` }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const taskId = submitData?.result?.task_id;
      if (!taskId) {
        return new Response(
          JSON.stringify({ error: '提交转换任务失败：未获取到任务ID' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      taskIds.push(taskId);
    }

    // 轮询获取所有任务结果（最多20次，每次5秒间隔）
    const downloadUrls: string[] = [];
    const pendingTaskIds = [...taskIds];

    for (let attempt = 0; attempt < 20 && pendingTaskIds.length > 0; attempt++) {
      await sleep(5000);

      const completedIndexes: number[] = [];

      for (let i = 0; i < pendingTaskIds.length; i++) {
        const taskId = pendingTaskIds[i];
        const getRes = await fetch(DOC_CONVERT_GET_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Gateway-Authorization': authHeader,
          },
          body: `task_id=${encodeURIComponent(taskId)}`,
        });

        if (!getRes.ok) continue;

        const getData = await getRes.json();
        const retCode = getData?.result?.ret_code;

        // ret_code: 1=未开始, 2=进行中, 3=完成
        if (retCode === 3) {
          const wordUrl = getData?.result?.result_data?.word;
          if (wordUrl) {
            downloadUrls.push(wordUrl);
          }
          completedIndexes.push(i);
        }
        // ret_code 1 或 2 继续轮询
      }

      // 移除已完成的任务（倒序移除避免索引错乱）
      for (let i = completedIndexes.length - 1; i >= 0; i--) {
        pendingTaskIds.splice(completedIndexes[i], 1);
      }
    }

    if (downloadUrls.length === 0) {
      return new Response(
        JSON.stringify({ error: '文档转换超时或失败，请稍后重试' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ download_urls: downloadUrls, total: downloadUrls.length }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('export-pdf error:', error);
    return new Response(
      JSON.stringify({ error: `导出失败: ${error instanceof Error ? error.message : String(error)}` }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
