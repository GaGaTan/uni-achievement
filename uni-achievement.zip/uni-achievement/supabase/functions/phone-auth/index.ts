import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

// 自定义短信 API 地址
const SMS_SEND_URL = 'https://app-bg335ysc0we9-api-W9z3M74x6ZNL-gateway.appmiaoda.com/v1/code/send_message';
const SMS_VERIFY_URL = 'https://app-bg335ysc0we9-api-Xa6JZxjyqK0a-gateway.appmiaoda.com/v1/code/verify_message_code';

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

  if (!apiKey || !supabaseUrl || !serviceRoleKey) {
    return new Response(
      JSON.stringify({ error: '服务配置缺失' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  try {
    const body = await req.json();
    const { action, phone, code, sessionId } = body;

    // 标准化手机号（去掉+86前缀）
    const normalizedPhone = phone.replace(/^\+86/, '');

    // ── 发送验证码 ─────────────────────────────────────────────────────
    if (action === 'send') {
      const resp = await fetch(SMS_SEND_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Gateway-Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({ mobile: normalizedPhone }),
      });

      if (!resp.ok) {
        const errText = await resp.text();
        return new Response(
          JSON.stringify({ error: `短信发送失败：${errText}` }),
          { status: resp.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const data = await resp.json();
      if (data.status !== 0) {
        return new Response(
          JSON.stringify({ error: data.msg || '短信发送失败' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true, sessionId: data.data.sessionId }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // ── 验证验证码 + 创建/登录 Supabase 用户 ──────────────────────────
    if (action === 'verify') {
      if (!code || !sessionId) {
        return new Response(
          JSON.stringify({ error: '缺少验证码或会话ID' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // 1. 验证验证码
      const verifyResp = await fetch(SMS_VERIFY_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Gateway-Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({ sessionId, code, mobile: normalizedPhone }),
      });

      if (!verifyResp.ok) {
        const errText = await verifyResp.text();
        return new Response(
          JSON.stringify({ error: `验证失败：${errText}` }),
          { status: verifyResp.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const verifyData = await verifyResp.json();
      if (verifyData.status !== 0) {
        return new Response(
          JSON.stringify({ error: verifyData.msg || '验证码错误或已过期' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // 2. 使用 service_role key 创建或获取 Supabase 用户
      const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey);
      const email = `phone_${normalizedPhone}@miaoda.com`;

      // 尝试获取已有用户
      const { data: listData } = await supabaseAdmin.auth.admin.listUsers();
      const existingUser = listData?.users?.find((u) => u.email === email);

      let userId: string;
      let isNew = false;

      if (existingUser) {
        userId = existingUser.id;
      } else {
        // 新用户：注册
        const password = crypto.randomUUID() + crypto.randomUUID() + 'Aa1!';
        const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
          email,
          password,
          email_confirm: true,
          user_metadata: { phone: normalizedPhone },
        });
        if (createError || !newUser?.user) {
          return new Response(
            JSON.stringify({ error: `创建用户失败：${createError?.message}` }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        userId = newUser.user.id;
        isNew = true;
      }

      // 3. 生成魔法链接以获取 session token
      const { data: linkData, error: linkError } = await supabaseAdmin.auth.admin.generateLink({
        type: 'magiclink',
        email,
      });

      if (linkError || !linkData?.properties?.hashed_token) {
        return new Response(
          JSON.stringify({ error: `生成登录令牌失败：${linkError?.message}` }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({
          success: true,
          hashed_token: linkData.properties.hashed_token,
          is_new_user: isNew,
          user_id: userId,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ error: '未知操作类型' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    console.error('phone-auth error:', err);
    return new Response(
      JSON.stringify({ error: `请求处理失败：${err instanceof Error ? err.message : String(err)}` }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
