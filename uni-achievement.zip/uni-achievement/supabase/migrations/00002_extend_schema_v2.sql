
-- 1. 扩展 achievements 表
ALTER TABLE achievements
  ADD COLUMN IF NOT EXISTS file_type text DEFAULT 'image' CHECK (file_type IN ('image','pdf','word','excel','link')),
  ADD COLUMN IF NOT EXISTS file_url text,
  ADD COLUMN IF NOT EXISTS file_path text,
  ADD COLUMN IF NOT EXISTS tags text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS is_private boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS custom_category text,
  ADD COLUMN IF NOT EXISTS volunteer_hours numeric(6,1),
  ADD COLUMN IF NOT EXISTS version_group_id uuid,
  ADD COLUMN IF NOT EXISTS certificate_size text CHECK (certificate_size IN ('1inch','2inch',null)),
  ADD COLUMN IF NOT EXISTS certificate_bg text CHECK (certificate_bg IN ('white','blue','red',null));

-- 2. 扩展 profiles 表（系统设置字段）
ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS backup_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS backup_frequency text DEFAULT 'weekly' CHECK (backup_frequency IN ('daily','weekly','monthly')),
  ADD COLUMN IF NOT EXISTS reminder_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS reminder_scenes text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS app_lock_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS app_lock_pin text;

-- 3. 私密账号密码表
CREATE TABLE account_secrets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  platform_name text NOT NULL,
  username_encrypted text NOT NULL,
  password_encrypted text NOT NULL,
  notes text,
  is_locked boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE account_secrets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "用户只能访问自己的账号密码" ON account_secrets
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 4. 回收站表
CREATE TABLE recycle_bin (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  item_type text NOT NULL DEFAULT 'achievement' CHECK (item_type IN ('achievement','account_secret')),
  original_id uuid NOT NULL,
  item_data jsonb NOT NULL,
  deleted_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT (now() + INTERVAL '30 days')
);

ALTER TABLE recycle_bin ENABLE ROW LEVEL SECURITY;

CREATE POLICY "用户只能访问自己的回收站" ON recycle_bin
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 5. 分享链接表
CREATE TABLE share_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT '我的成就档案',
  achievement_ids uuid[] NOT NULL DEFAULT '{}',
  is_public boolean NOT NULL DEFAULT true,
  password text,
  expires_at timestamptz,
  access_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE share_links ENABLE ROW LEVEL SECURITY;

CREATE POLICY "用户只能管理自己的分享链接" ON share_links
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "公开分享链接任何人可查看" ON share_links
  FOR SELECT TO anon, authenticated USING (is_public = true AND (expires_at IS NULL OR expires_at > now()));

-- 开启 realtime（可选）
ALTER PUBLICATION supabase_realtime ADD TABLE account_secrets;

-- 自动更新 updated_at 触发器
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TRIGGER account_secrets_updated_at
  BEFORE UPDATE ON account_secrets
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
