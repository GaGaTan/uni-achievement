import { HelpCircle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

interface HelpTipProps {
  content: string;
  className?: string;
  side?: 'top' | 'right' | 'bottom' | 'left';
  maxWidth?: string;
}

/**
 * 功能说明提示组件
 * 在功能旁显示一个问号图标，悬停/点击后展示功能说明
 */
export function HelpTip({ content, className, side = 'top', maxWidth = '240px' }: HelpTipProps) {
  return (
    <TooltipProvider delayDuration={200}>
      <Tooltip>
        <TooltipTrigger asChild>
          <span
            className={cn(
              'inline-flex items-center justify-center w-4 h-4 rounded-full text-muted-foreground hover:text-foreground cursor-help transition-colors shrink-0',
              className
            )}
            aria-label="功能说明"
          >
            <HelpCircle className="w-3.5 h-3.5" />
          </span>
        </TooltipTrigger>
        <TooltipContent side={side} style={{ maxWidth }}>
          <p className="text-xs leading-relaxed text-pretty">{content}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

interface TipBannerProps {
  children: React.ReactNode;
  className?: string;
  variant?: 'info' | 'warning' | 'success';
}

/**
 * 功能说明横幅（适合放在功能区顶部）
 */
export function TipBanner({ children, className, variant = 'info' }: TipBannerProps) {
  const variantStyles = {
    info: 'bg-blue-50 border-blue-200 text-blue-700 dark:bg-blue-950/30 dark:border-blue-900 dark:text-blue-300',
    warning: 'bg-amber-50 border-amber-200 text-amber-700 dark:bg-amber-950/30 dark:border-amber-900 dark:text-amber-300',
    success: 'bg-green-50 border-green-200 text-green-700 dark:bg-green-950/30 dark:border-green-900 dark:text-green-300',
  };
  return (
    <div className={cn(
      'flex items-start gap-2 rounded-lg border px-3 py-2.5 text-xs leading-relaxed',
      variantStyles[variant],
      className
    )}>
      <HelpCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
      <div className="text-pretty">{children}</div>
    </div>
  );
}
