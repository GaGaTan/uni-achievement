import { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';
import { useAuth } from '@/contexts/AuthContext';
import {
  LayoutDashboard,
  Upload,
  FileDown,
  User,
  Award,
  Menu,
  LogIn,
  X,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface NavItem {
  label: string;
  path: string;
  icon: React.ComponentType<{ className?: string }>;
  requireAuth: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { label: '成就总览', path: '/', icon: LayoutDashboard, requireAuth: true },
  { label: '上传归档', path: '/upload', icon: Upload, requireAuth: true },
  { label: '导出材料', path: '/export', icon: FileDown, requireAuth: true },
  { label: '个人中心', path: '/profile', icon: User, requireAuth: true },
];

// 侧边栏导航内容（复用于桌面和移动端）
function SidebarContent({ onNavClick }: { onNavClick?: () => void }) {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const username = user?.email?.replace('@miaoda.com', '') || '';

  return (
    <div className="flex flex-col h-full">
      {/* Logo区域 */}
      <div className="flex items-center gap-3 px-5 py-5">
        <div className="w-9 h-9 bg-sidebar-primary rounded-lg flex items-center justify-center shrink-0">
          <Award className="w-5 h-5 text-sidebar-primary-foreground" />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-sidebar-foreground truncate">成就档案</p>
          <p className="text-xs text-sidebar-foreground/50 truncate">大学生成就整理系统</p>
        </div>
      </div>

      <Separator className="bg-sidebar-border" />

      {/* 用户信息 */}
      {user && (
        <div className="px-4 py-3">
          <div className="flex items-center gap-3 px-2 py-2 rounded-lg bg-sidebar-accent/40">
            <div className="w-8 h-8 bg-sidebar-primary/20 rounded-lg flex items-center justify-center shrink-0">
              <span className="text-sm font-bold text-sidebar-primary">
                {(profile?.name || username).charAt(0).toUpperCase()}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-sidebar-foreground truncate">
                {profile?.name || username}
              </p>
              {profile?.school && (
                <p className="text-xs text-sidebar-foreground/50 truncate">{profile.school}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 导航菜单 */}
      <nav className="flex-1 px-3 py-2 space-y-1">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.path === '/'}
            onClick={onNavClick}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors min-h-12',
                isActive
                  ? 'bg-sidebar-primary text-sidebar-primary-foreground font-medium'
                  : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
              )
            }
          >
            <item.icon className="w-4 h-4 shrink-0" />
            {item.label}
          </NavLink>
        ))}
      </nav>

      {/* 底部操作 */}
      <div className="px-3 pb-4">
        <Separator className="bg-sidebar-border mb-3" />
        {!user && (
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            onClick={() => {
              navigate('/auth');
              onNavClick?.();
            }}
          >
            <LogIn className="w-4 h-4 mr-2" />
            登录 / 注册
          </Button>
        )}
      </div>
    </div>
  );
}

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="flex min-h-screen w-full">
      {/* 桌面端侧边栏 */}
      <aside className="hidden lg:flex flex-col w-60 shrink-0 bg-sidebar border-r border-sidebar-border">
        <SidebarContent />
      </aside>

      {/* 主内容区 */}
      <div className="flex-1 min-w-0 flex flex-col overflow-x-hidden">
        {/* 移动端顶部栏 */}
        <header className="flex lg:hidden items-center gap-3 px-4 py-3 border-b border-border bg-background sticky top-0 z-10">
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="sm" className="h-9 w-9 p-0">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent
              side="left"
              className="w-64 p-0 bg-sidebar"
            >
              {/* 关闭按钮 */}
              <button
                type="button"
                className="absolute right-4 top-4 z-10 opacity-70 hover:opacity-100"
                onClick={() => setMobileMenuOpen(false)}
              >
                <X className="w-5 h-5 text-sidebar-foreground" />
              </button>
              <SidebarContent onNavClick={() => setMobileMenuOpen(false)} />
            </SheetContent>
          </Sheet>

          <div className="flex items-center gap-2 flex-1 min-w-0">
            <div className="w-7 h-7 bg-primary rounded flex items-center justify-center shrink-0">
              <Award className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-semibold text-foreground text-sm truncate">成就档案</span>
          </div>
        </header>

        {/* 页面内容 */}
        <main className="flex-1 p-4 md:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
