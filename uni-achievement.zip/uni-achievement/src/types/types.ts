export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

// 用户档案
export interface Profile {
  id: string;
  email: string | null;
  phone: string | null;
  role: 'user' | 'admin';
  name: string | null;
  school: string | null;
  student_id: string | null;
  enrollment_year: number | null;
  study_years: number | null;
  education_level: string | null;
  sound_reminder: boolean;
  profile_completed: boolean;
  // 系统设置
  backup_enabled: boolean;
  backup_frequency: 'daily' | 'weekly' | 'monthly';
  reminder_enabled: boolean;
  reminder_scenes: string[];
  app_lock_enabled: boolean;
  app_lock_pin: string | null;
  created_at: string;
  updated_at: string;
}

// 成就材料分类（全品类）
export const ACHIEVEMENT_CATEGORIES = [
  { value: '荣誉奖项', label: '荣誉奖项', icon: '🏆' },
  { value: '赛事竞赛', label: '赛事竞赛', icon: '🥇' },
  { value: '志愿实践', label: '志愿实践', icon: '🤝' },
  { value: '学术成果', label: '学术成果', icon: '📚' },
  { value: '学生工作', label: '学生工作', icon: '💼' },
  { value: '个人证件', label: '个人证件', icon: '🪪' },
  { value: '私密账号', label: '私密账号', icon: '🔐' },
  { value: '其他', label: '其他', icon: '📄' },
] as const;

// 荣誉奖项子分类
export const HONOR_SUBCATEGORIES = [
  { value: '国家级奖项', label: '国家级奖项' },
  { value: '省级奖项', label: '省级奖项' },
  { value: '校级奖项', label: '校级奖项' },
  { value: '院级奖项', label: '院级奖项' },
];

// 赛事竞赛子分类
export const COMPETITION_SUBCATEGORIES = [
  { value: '学科竞赛', label: '学科竞赛' },
  { value: '创新创业竞赛', label: '创新创业竞赛' },
  { value: '文体竞赛', label: '文体竞赛' },
  { value: '其他竞赛', label: '其他竞赛' },
];

// 志愿实践子分类
export const VOLUNTEER_SUBCATEGORIES = [
  { value: '志愿服务', label: '志愿服务' },
  { value: '社会实践', label: '社会实践' },
  { value: '实习经历', label: '实习经历' },
];

// 学术成果子分类
export const ACADEMIC_SUBCATEGORIES = [
  { value: '发表论文', label: '发表论文' },
  { value: '录用通知', label: '录用通知' },
  { value: '软著/专利', label: '软著/专利' },
  { value: '微刊/新媒体发表', label: '微刊/新媒体发表' },
  { value: '新闻报道', label: '新闻报道' },
];

// 学生工作子分类
export const STUDENT_WORK_SUBCATEGORIES = [
  { value: '聘书', label: '聘书' },
  { value: '学生干部任职证明', label: '学生干部任职证明' },
  { value: '评优任职证明', label: '评优任职证明' },
];

// 奖项等级
export const ACHIEVEMENT_LEVELS = [
  { value: '国家级', label: '国家级' },
  { value: '省级', label: '省级' },
  { value: '校级', label: '校级' },
  { value: '院级', label: '院级' },
  { value: '其他', label: '其他' },
];

// 学历层次
export const EDUCATION_LEVELS = [
  { value: '本科', label: '本科' },
  { value: '硕士', label: '硕士' },
  { value: '博士', label: '博士' },
];

// 学制选项
export const STUDY_YEARS_OPTIONS = [
  { value: 2, label: '2年' },
  { value: 3, label: '3年' },
  { value: 4, label: '4年' },
  { value: 5, label: '5年' },
];

// 成就材料
export interface Achievement {
  id: string;
  user_id: string;
  name: string;
  category: string;
  subcategory: string | null;
  level: string | null;
  grade_year: number | null;
  achieved_at: string | null;
  // 图片字段
  image_url: string;
  image_path: string;
  // 文件字段（非图片类型）
  file_type: 'image' | 'pdf' | 'word' | 'excel' | 'link';
  file_url: string | null;
  file_path: string | null;
  // 扩展字段
  tags: string[];
  is_private: boolean;
  custom_category: string | null;
  volunteer_hours: number | null;
  version_group_id: string | null;
  certificate_size: '1inch' | '2inch' | null;
  certificate_bg: 'white' | 'blue' | 'red' | null;
  ai_description: string | null;
  ai_keywords: string[] | null;
  notes: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

// 私密账号密码
export interface AccountSecret {
  id: string;
  user_id: string;
  platform_name: string;
  username_encrypted: string;
  password_encrypted: string;
  notes: string | null;
  is_locked: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

// 回收站记录
export interface RecycleBinItem {
  id: string;
  user_id: string;
  item_type: 'achievement' | 'account_secret';
  original_id: string;
  item_data: Achievement | AccountSecret;
  deleted_at: string;
  expires_at: string;
}

// 分享链接
export interface ShareLink {
  id: string;
  user_id: string;
  title: string;
  achievement_ids: string[];
  is_public: boolean;
  password: string | null;
  expires_at: string | null;
  access_count: number;
  created_at: string;
}

// AI分析结果
export interface AIAnalysisResult {
  suggested_name: string;
  suggested_category: string;
  suggested_subcategory: string | null;
  suggested_level: string | null;
  suggested_date: string | null;
  description: string;
  keywords: string[];
  ocr_text: string;
}

// 筛选条件
export interface AchievementFilter {
  category?: string;
  level?: string;
  grade_year?: number;
  year?: number;
  keyword?: string;
  tags?: string[];
}

// 个人证件子分类
export const CERTIFICATE_SUBCATEGORIES = [
  { value: '一寸证件照（白底）', label: '一寸证件照（白底）' },
  { value: '一寸证件照（蓝底）', label: '一寸证件照（蓝底）' },
  { value: '一寸证件照（红底）', label: '一寸证件照（红底）' },
  { value: '两寸证件照（白底）', label: '两寸证件照（白底）' },
  { value: '两寸证件照（蓝底）', label: '两寸证件照（蓝底）' },
  { value: '两寸证件照（红底）', label: '两寸证件照（红底）' },
  { value: '其他证件资料', label: '其他证件资料' },
];

// 场景标签
export const SCENE_TAGS = [
  { value: '保研加分', label: '保研加分' },
  { value: '综测加分', label: '综测加分' },
  { value: '求职简历', label: '求职简历' },
  { value: '入党材料', label: '入党材料' },
  { value: '复试材料', label: '复试材料' },
  { value: '奖学金申请', label: '奖学金申请' },
  { value: '交流项目', label: '交流项目' },
];

// 导出场景模板
export const EXPORT_TEMPLATES = [
  { value: 'comprehensive', label: '综测评奖', icon: '🏅', description: '综合测评所需全套材料，含奖项、志愿、任职证明', categories: ['荣誉奖项', '志愿实践', '学生工作', '赛事竞赛'] },
  { value: 'postgrad', label: '保研申请', icon: '🎓', description: '保研推免所需成果，含获奖、论文、竞赛材料', categories: ['荣誉奖项', '学术成果', '赛事竞赛'] },
  { value: 'job', label: '求职简历附件', icon: '💼', description: '求职投递附件，含实习证明、获奖、任职经历', categories: ['志愿实践', '荣誉奖项', '学生工作'] },
  { value: 'exam', label: '升学复试', icon: '📝', description: '升学面试材料，含学术成果、获奖证明', categories: ['学术成果', '荣誉奖项'] },
  { value: 'party', label: '入党材料', icon: '🌹', description: '入党审核材料，含志愿证明、任职、获奖', categories: ['志愿实践', '学生工作', '荣誉奖项'] },
  { value: 'internship', label: '实习任职履历', icon: '🗂️', description: '实习与任职经历汇总，适合简历整理', categories: ['志愿实践', '学生工作'] },
  { value: 'cert_photo', label: '证件照资料包', icon: '🪪', description: '各尺寸、各底色证件照全套打包', categories: ['个人证件'] },
] as const;

// 年级计算工具
export function calcGradeYear(enrollmentYear: number, achievedAt?: string): number {
  const refDate = achievedAt ? new Date(achievedAt) : new Date();
  const refYear = refDate.getFullYear();
  const refMonth = refDate.getMonth() + 1;
  // 入学月份通常9月，新学年从9月开始
  const academicYear = refMonth >= 9 ? refYear : refYear - 1;
  return academicYear - enrollmentYear + 1;
}

export function getGradeLabel(gradeYear: number, educationLevel: string): string {
  if (educationLevel === '本科') {
    const labels = ['大一', '大二', '大三', '大四', '大五'];
    return labels[gradeYear - 1] || `大${gradeYear}`;
  } else if (educationLevel === '硕士') {
    const labels = ['研一', '研二', '研三'];
    return labels[gradeYear - 1] || `研${gradeYear}`;
  } else if (educationLevel === '博士') {
    const labels = ['博一', '博二', '博三', '博四'];
    return labels[gradeYear - 1] || `博${gradeYear}`;
  }
  return `第${gradeYear}年`;
}
