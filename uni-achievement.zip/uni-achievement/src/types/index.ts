export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

// 用户档案
export interface Profile {
  id: string;
  email: string | null;
  phone: string | null;
  role: 'user' | 'admin';
  name: string | null;
  school: string | null;
  student_id: string | null;
  enrollment_year: number | null;
  study_years: number | null;
  education_level: string | null;
  sound_reminder: boolean;
  profile_completed: boolean;
  created_at: string;
  updated_at: string;
}

// 成就材料分类
export const ACHIEVEMENT_CATEGORIES = [
  { value: '荣誉奖项', label: '荣誉奖项', icon: '🏆' },
  { value: '赛事竞赛', label: '赛事竞赛', icon: '🥇' },
  { value: '志愿实践', label: '志愿实践', icon: '🤝' },
  { value: '学术成果', label: '学术成果', icon: '📚' },
  { value: '学生工作', label: '学生工作', icon: '💼' },
  { value: '其他', label: '其他', icon: '📄' },
] as const;

// 荣誉奖项子分类
export const HONOR_SUBCATEGORIES = [
  { value: '国家级奖项', label: '国家级奖项' },
  { value: '省级奖项', label: '省级奖项' },
  { value: '校级奖项', label: '校级奖项' },
  { value: '院级奖项', label: '院级奖项' },
];

// 赛事竞赛子分类
export const COMPETITION_SUBCATEGORIES = [
  { value: '学科竞赛', label: '学科竞赛' },
  { value: '创新创业竞赛', label: '创新创业竞赛' },
  { value: '文体竞赛', label: '文体竞赛' },
  { value: '其他竞赛', label: '其他竞赛' },
];

// 志愿实践子分类
export const VOLUNTEER_SUBCATEGORIES = [
  { value: '志愿服务', label: '志愿服务' },
  { value: '社会实践', label: '社会实践' },
  { value: '实习经历', label: '实习经历' },
];

// 学术成果子分类
export const ACADEMIC_SUBCATEGORIES = [
  { value: '发表论文', label: '发表论文' },
  { value: '录用通知', label: '录用通知' },
  { value: '软著/专利', label: '软著/专利' },
  { value: '微刊/新媒体发表', label: '微刊/新媒体发表' },
  { value: '新闻报道', label: '新闻报道' },
];

// 学生工作子分类
export const STUDENT_WORK_SUBCATEGORIES = [
  { value: '任职证明', label: '任职证明' },
  { value: '评优证明', label: '评优证明' },
];

// 奖项等级
export const ACHIEVEMENT_LEVELS = [
  { value: '国家级', label: '国家级' },
  { value: '省级', label: '省级' },
  { value: '校级', label: '校级' },
  { value: '院级', label: '院级' },
  { value: '其他', label: '其他' },
];

// 学历层次
export const EDUCATION_LEVELS = [
  { value: '本科', label: '本科' },
  { value: '硕士', label: '硕士' },
  { value: '博士', label: '博士' },
];

// 学制选项
export const STUDY_YEARS_OPTIONS = [
  { value: 2, label: '2年' },
  { value: 3, label: '3年' },
  { value: 4, label: '4年' },
  { value: 5, label: '5年' },
];

// 成就材料
export interface Achievement {
  id: string;
  user_id: string;
  name: string;
  category: string;
  subcategory: string | null;
  level: string | null;
  grade_year: number | null;
  achieved_at: string | null;
  image_url: string;
  image_path: string;
  ai_description: string | null;
  ai_keywords: string[] | null;
  notes: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

// AI分析结果
export interface AIAnalysisResult {
  suggested_name: string;
  suggested_category: string;
  suggested_subcategory: string | null;
  suggested_level: string | null;
  suggested_date: string | null;
  description: string;
  keywords: string[];
  ocr_text: string;
}

// 筛选条件
export interface AchievementFilter {
  category?: string;
  level?: string;
  grade_year?: number;
  year?: number;
}

// 年级计算工具
export function calcGradeYear(enrollmentYear: number, achievedAt?: string): number {
  const refDate = achievedAt ? new Date(achievedAt) : new Date();
  const refYear = refDate.getFullYear();
  const refMonth = refDate.getMonth() + 1;
  // 入学月份通常9月，新学年从9月开始
  const academicYear = refMonth >= 9 ? refYear : refYear - 1;
  return academicYear - enrollmentYear + 1;
}

export function getGradeLabel(gradeYear: number, educationLevel: string): string {
  if (educationLevel === '本科') {
    const labels = ['大一', '大二', '大三', '大四', '大五'];
    return labels[gradeYear - 1] || `大${gradeYear}`;
  } else if (educationLevel === '硕士') {
    const labels = ['研一', '研二', '研三'];
    return labels[gradeYear - 1] || `研${gradeYear}`;
  } else if (educationLevel === '博士') {
    const labels = ['博一', '博二', '博三', '博四'];
    return labels[gradeYear - 1] || `博${gradeYear}`;
  }
  return `第${gradeYear}年`;
}
