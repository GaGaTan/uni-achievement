import type { ReactNode } from 'react';
import AuthPage from './pages/AuthPage';
import SetupPage from './pages/SetupPage';
import HomePage from './pages/HomePage';
import UploadPage from './pages/UploadPage';
import ExportPage from './pages/ExportPage';
import ProfilePage from './pages/ProfilePage';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  /** 不需要登录即可访问 */
  public?: boolean;
  /** 是否使用主布局（侧边栏） */
  useLayout?: boolean;
}

export const routes: RouteConfig[] = [
  {
    name: '登录/注册',
    path: '/auth',
    element: <AuthPage />,
    public: true,
    useLayout: false,
  },
  {
    name: '档案设置',
    path: '/setup',
    element: <SetupPage />,
    useLayout: false,
  },
  {
    name: '成就总览',
    path: '/',
    element: <HomePage />,
    visible: true,
    useLayout: true,
  },
  {
    name: '上传归档',
    path: '/upload',
    element: <UploadPage />,
    visible: true,
    useLayout: true,
  },
  {
    name: '导出材料',
    path: '/export',
    element: <ExportPage />,
    visible: true,
    useLayout: true,
  },
  {
    name: '个人中心',
    path: '/profile',
    element: <ProfilePage />,
    visible: true,
    useLayout: true,
  },
];
