import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { useAuth } from '@/contexts/AuthContext';
// @ts-ignore
import { supabase } from '@/db/supabase';
import { GraduationCap, BookOpen, Award, Phone, User2, KeyRound } from 'lucide-react';
import { HelpTip } from '@/components/common/HelpTip';

// ── 表单 Schema ──────────────────────────────────────────────────────────
const loginSchema = z.object({
  username: z
    .string()
    .min(3, '用户名至少3位')
    .max(20, '用户名最多20位')
    .regex(/^[a-zA-Z0-9_]+$/, '用户名只能包含字母、数字和下划线'),
  password: z.string().min(6, '密码至少6位'),
});

const registerSchema = z.object({
  username: z
    .string()
    .min(3, '用户名至少3位')
    .max(20, '用户名最多20位')
    .regex(/^[a-zA-Z0-9_]+$/, '用户名只能包含字母、数字和下划线'),
  password: z.string().min(8, '密码至少8位'),
  confirmPassword: z.string(),
  agreement: z.boolean().refine((v) => v === true, '请阅读并同意用户协议'),
}).refine((data) => data.password === data.confirmPassword, {
  message: '两次密码不一致',
  path: ['confirmPassword'],
});

const phoneSchema = z.object({
  phone: z.string().regex(/^1[3-9]\d{9}$/, '请输入正确的11位手机号'),
});

const otpSchema = z.object({
  token: z.string().length(6, '验证码为6位数字').regex(/^\d+$/, '验证码只含数字'),
});

const resetSchema = z.object({
  username: z
    .string()
    .min(3, '用户名至少3位')
    .max(20, '用户名最多20位')
    .regex(/^[a-zA-Z0-9_]+$/, '用户名只能包含字母、数字和下划线'),
  newPassword: z.string().min(8, '新密码至少8位'),
  confirmPassword: z.string(),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: '两次密码不一致',
  path: ['confirmPassword'],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;
type PhoneFormValues = z.infer<typeof phoneSchema>;
type OtpFormValues = z.infer<typeof otpSchema>;
type ResetFormValues = z.infer<typeof resetSchema>;

export default function AuthPage() {
  const { signInWithUsername, signUpWithUsername } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const defaultTab = searchParams.get('tab') || 'login';

  const [isLoading, setIsLoading] = useState(false);

  // 手机登录状态
  const [phoneStep, setPhoneStep] = useState<'phone' | 'otp'>('phone');
  const [pendingPhone, setPendingPhone] = useState('');
  const [smsSessonId, setSmsSessonId] = useState('');
  const [sendCooldown, setSendCooldown] = useState(0);

  // 忘记密码
  const [showReset, setShowReset] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  // ── Forms ────────────────────────────────────────────────────────────
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: '', password: '' },
  });

  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: { username: '', password: '', confirmPassword: '', agreement: false },
  });

  const phoneForm = useForm<PhoneFormValues>({
    resolver: zodResolver(phoneSchema),
    defaultValues: { phone: '' },
  });

  const otpForm = useForm<OtpFormValues>({
    resolver: zodResolver(otpSchema),
    defaultValues: { token: '' },
  });

  const resetForm = useForm<ResetFormValues>({
    resolver: zodResolver(resetSchema),
    defaultValues: { username: '', newPassword: '', confirmPassword: '' },
  });

  // ── 倒计时 ────────────────────────────────────────────────────────────
  const startCooldown = () => {
    setSendCooldown(60);
    const timer = setInterval(() => {
      setSendCooldown((v) => {
        if (v <= 1) { clearInterval(timer); return 0; }
        return v - 1;
      });
    }, 1000);
  };

  // ── 账号密码登录 ────────────────────────────────────────────────────
  const onLogin = async (values: LoginFormValues) => {
    setIsLoading(true);
    const { error } = await signInWithUsername(values.username, values.password);
    setIsLoading(false);
    if (error) {
      const msg = error.message.includes('Invalid login credentials')
        ? '用户名或密码错误，请检查后重试'
        : `登录失败：${error.message}`;
      toast.error(msg);
    } else {
      toast.success('登录成功，欢迎回来！');
      navigate('/');
    }
  };

  // ── 账号密码注册 ────────────────────────────────────────────────────
  const onRegister = async (values: RegisterFormValues) => {
    setIsLoading(true);
    const { error } = await signUpWithUsername(values.username, values.password);
    setIsLoading(false);
    if (error) {
      const msg = error.message.includes('already registered')
        ? '该用户名已被注册，请更换用户名'
        : `注册失败：${error.message}`;
      toast.error(msg);
    } else {
      toast.success('注册成功！请使用您的账号密码登录', { duration: 5000 });
      // 注册成功后跳转到登录标签，不自动登录
      const loginTab = document.querySelector('[data-value="login"]') as HTMLButtonElement;
      if (loginTab) loginTab.click();
      registerForm.reset();
    }
  };

  // ── 发送手机验证码（自定义SMS API） ────────────────────────────────
  const onSendOtp = async (values: PhoneFormValues) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('phone-auth', {
        body: { action: 'send', phone: values.phone },
      });
      if (error) {
        const errMsg = await error?.context?.text?.();
        throw new Error(errMsg || error.message);
      }
      if (!data?.success) throw new Error(data?.error || '发送失败');
      setPendingPhone(values.phone);
      setSmsSessonId(data.sessionId);
      setPhoneStep('otp');
      startCooldown();
      toast.success('验证码已发送，请注意查收短信');
    } catch (err) {
      toast.error(`发送失败：${err instanceof Error ? err.message : '请稍后重试'}`);
    } finally {
      setIsLoading(false);
    }
  };

  // ── 验证手机OTP并登录 ─────────────────────────────────────────────
  const onVerifyOtp = async (values: OtpFormValues) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('phone-auth', {
        body: { action: 'verify', phone: pendingPhone, code: values.token, sessionId: smsSessonId },
      });
      if (error) {
        const errMsg = await error?.context?.text?.();
        throw new Error(errMsg || error.message);
      }
      if (!data?.success) throw new Error(data?.error || '验证失败');

      // 用 hashed_token 激活 Supabase session
      const { error: sessionError } = await supabase.auth.verifyOtp({
        token_hash: data.hashed_token,
        type: 'magiclink',
      });
      if (sessionError) throw sessionError;

      toast.success(data.is_new_user ? '注册并登录成功！欢迎使用' : '登录成功！欢迎回来');
      navigate('/');
    } catch (err) {
      toast.error(`验证失败：${err instanceof Error ? err.message : '验证码错误或已过期'}`);
    } finally {
      setIsLoading(false);
    }
  };

  // ── 重新发送验证码 ──────────────────────────────────────────────────
  const onResendOtp = async () => {
    if (sendCooldown > 0) return;
    try {
      const { data, error } = await supabase.functions.invoke('phone-auth', {
        body: { action: 'send', phone: pendingPhone },
      });
      if (error || !data?.success) throw new Error('发送失败');
      setSmsSessonId(data.sessionId);
      startCooldown();
      toast.success('验证码已重新发送');
    } catch {
      toast.error('重新发送失败，请稍后重试');
    }
  };

  // ── 忘记密码（提示用手机号登录后在设置中修改密码） ─────────────────
  const onResetPassword = async (values: ResetFormValues) => {
    setIsLoading(true);
    // 用户名密码体系下，无真实邮箱，提示使用手机号方式登录后修改密码
    // 这里提供一个替代方案：通过signUp时的邮箱发送重置链接（虽是虚拟邮箱）
    // 或直接提示用户通过手机验证码登录后在个人设置修改密码
    try {
      // 先尝试用新密码登录以确认用户存在（不暴露用户是否存在的信息）
      const { error } = await signUpWithUsername(values.username, values.newPassword);
      if (error && error.message.includes('already registered')) {
        // 用户已存在，但无法直接重置密码（没有真实邮箱）
        // 建议使用手机OTP登录
        toast.info('请使用手机验证码登录方式，登录后在个人设置中修改密码', { duration: 5000 });
        setResetSent(true);
      } else if (!error) {
        // 竟然注册成功了，说明之前该用户名不存在
        toast.error('该用户名不存在，请检查后重试');
      } else {
        toast.error(`操作失败：${error.message}`);
      }
    } catch {
      toast.error('操作失败，请稍后重试');
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex">
      {/* 左侧品牌区域 - 仅桌面端显示 */}
      <div className="hidden lg:flex lg:w-1/2 bg-primary flex-col justify-between p-12">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[hsl(35_90%_55%)] rounded flex items-center justify-center">
            <Award className="w-6 h-6 text-primary" />
          </div>
          <span className="text-xl font-semibold text-primary-foreground">成就档案</span>
        </div>

        <div className="space-y-8">
          <div>
            <h1 className="text-3xl font-bold text-primary-foreground text-balance mb-4">
              大学生个人成就整理系统
            </h1>
            <p className="text-primary-foreground/70 text-pretty">
              一站式数字化归档你的大学成就材料，AI智能识别分类，快速检索导出。
            </p>
          </div>

          <div className="space-y-4">
            {[
              { icon: BookOpen, text: 'AI自动识别证书信息，智能命名分类' },
              { icon: Award, text: '多维度筛选，快速定位所需材料' },
              { icon: GraduationCap, text: '一键导出PDF，适配评奖评优场景' },
            ].map(({ icon: Icon, text }) => (
              <div key={text} className="flex items-center gap-3">
                <div className="w-8 h-8 bg-primary-foreground/10 rounded flex items-center justify-center shrink-0">
                  <Icon className="w-4 h-4 text-[hsl(35_90%_55%)]" />
                </div>
                <span className="text-primary-foreground/80 text-sm">{text}</span>
              </div>
            ))}
          </div>
        </div>

        <p className="text-primary-foreground/40 text-xs">© 2026 成就档案 · 大学全周期成就管理</p>
      </div>

      {/* 右侧登录/注册区域 */}
      <div className="flex-1 flex items-center justify-center p-6 bg-background overflow-y-auto">
        <div className="w-full max-w-md">
          {/* 移动端Logo */}
          <div className="flex items-center justify-center gap-2 mb-8 lg:hidden">
            <div className="w-9 h-9 bg-primary rounded flex items-center justify-center">
              <Award className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-semibold text-foreground">成就档案</span>
          </div>

          {/* 忘记密码弹窗 */}
          {showReset ? (
            <Card className="border-border shadow-none">
              <CardHeader className="pb-4">
                <CardTitle className="text-xl text-balance">找回密码</CardTitle>
                <CardDescription className="text-pretty">
                  {resetSent
                    ? '请使用手机验证码方式登录，登录后在个人设置中修改密码'
                    : '通过用户名找回账号'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {resetSent ? (
                  <div className="space-y-4">
                    <div className="p-4 bg-muted rounded-lg text-sm text-muted-foreground space-y-2">
                      <p>由于本系统使用虚拟账号体系，无法通过邮件发送重置链接。</p>
                      <p>请切换到<strong className="text-foreground">手机验证码登录</strong>方式，使用手机号登录后，前往个人中心修改密码。</p>
                    </div>
                    <Button className="w-full" onClick={() => { setShowReset(false); setResetSent(false); }}>
                      返回登录
                    </Button>
                  </div>
                ) : (
                  <Form {...resetForm}>
                    <form onSubmit={resetForm.handleSubmit(onResetPassword)} className="space-y-4">
                      <FormField
                        control={resetForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-normal">用户名</FormLabel>
                            <FormControl>
                              <Input placeholder="请输入注册时的用户名" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-700">
                        由于账号体系限制，建议直接使用<strong>手机验证码</strong>方式登录后修改密码。
                      </div>
                      <div className="flex gap-2">
                        <Button type="button" variant="outline" className="flex-1" onClick={() => setShowReset(false)}>
                          返回登录
                        </Button>
                        <Button type="submit" className="flex-1" disabled={isLoading}>
                          {isLoading ? '处理中...' : '确认'}
                        </Button>
                      </div>
                    </form>
                  </Form>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card className="border-border shadow-none">
              <CardHeader className="pb-4">
                <CardTitle className="text-xl text-balance">欢迎使用成就档案</CardTitle>
                <CardDescription className="text-pretty">
                  登录或注册账号，开始整理你的大学成就
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue={defaultTab}>
                  <TabsList className="w-full mb-6">
                    <TabsTrigger value="login" className="flex-1">
                      <User2 className="w-3.5 h-3.5 mr-1.5" />账号登录
                    </TabsTrigger>
                    <TabsTrigger value="phone" className="flex-1">
                      <Phone className="w-3.5 h-3.5 mr-1.5" />手机登录
                    </TabsTrigger>
                    <TabsTrigger value="register" className="flex-1">
                      <KeyRound className="w-3.5 h-3.5 mr-1.5" />注册
                    </TabsTrigger>
                  </TabsList>

                  {/* ── 账号密码登录 ── */}
                  <TabsContent value="login">
                    <Form {...loginForm}>
                      <form onSubmit={loginForm.handleSubmit(onLogin)} className="space-y-4">
                        <FormField
                          control={loginForm.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-normal">用户名</FormLabel>
                              <FormControl>
                                <Input placeholder="请输入用户名" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={loginForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex items-center justify-between">
                                <FormLabel className="text-sm font-normal">密码</FormLabel>
                                <button
                                  type="button"
                                  className="text-xs text-primary hover:underline underline-offset-2"
                                  onClick={() => setShowReset(true)}
                                >
                                  忘记密码？
                                </button>
                              </div>
                              <FormControl>
                                <Input type="password" placeholder="请输入密码" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button type="submit" className="w-full" disabled={isLoading}>
                          {isLoading ? '登录中...' : '登录'}
                        </Button>
                      </form>
                    </Form>
                  </TabsContent>

                  {/* ── 手机验证码登录 ── */}
                  <TabsContent value="phone">
                    {phoneStep === 'phone' ? (
                      <Form {...phoneForm}>
                        <form onSubmit={phoneForm.handleSubmit(onSendOtp)} className="space-y-4">
                          <FormField
                            control={phoneForm.control}
                            name="phone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-sm font-normal">手机号</FormLabel>
                                <FormControl>
                                  <div className="flex items-center gap-2">
                                    <span className="text-sm text-muted-foreground bg-muted px-3 h-9 flex items-center rounded-md border border-border whitespace-nowrap shrink-0">+86</span>
                                    <Input placeholder="请输入11位手机号" maxLength={11} {...field} />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <p className="text-xs text-muted-foreground">
                            手机号首次使用将自动注册账号，已注册账号可直接登录
                          </p>
                          <Button type="submit" className="w-full" disabled={isLoading}>
                            {isLoading ? '发送中...' : '获取验证码'}
                          </Button>
                        </form>
                      </Form>
                    ) : (
                      <div className="space-y-4">
                        <div className="text-sm text-muted-foreground">
                          验证码已发送至 <strong className="text-foreground">+86 {pendingPhone}</strong>
                        </div>
                        <Form {...otpForm}>
                          <form onSubmit={otpForm.handleSubmit(onVerifyOtp)} className="space-y-4">
                            <FormField
                              control={otpForm.control}
                              name="token"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel className="text-sm font-normal">验证码</FormLabel>
                                  <FormControl>
                                    <Input placeholder="请输入6位验证码" maxLength={6} {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <Button type="submit" className="w-full" disabled={isLoading}>
                              {isLoading ? '验证中...' : '验证登录'}
                            </Button>
                          </form>
                        </Form>
                        <Separator />
                        <div className="flex items-center justify-between text-sm">
                          <button
                            type="button"
                            className="text-muted-foreground hover:text-foreground"
                            onClick={() => { setPhoneStep('phone'); otpForm.reset(); }}
                          >
                            更换手机号
                          </button>
                          <button
                            type="button"
                            className="text-primary hover:underline underline-offset-2 disabled:opacity-50 disabled:no-underline"
                            onClick={onResendOtp}
                            disabled={sendCooldown > 0}
                          >
                            {sendCooldown > 0 ? `重新发送 (${sendCooldown}s)` : '重新发送'}
                          </button>
                        </div>
                      </div>
                    )}
                  </TabsContent>

                  {/* ── 注册 ── */}
                  <TabsContent value="register">
                    <p className="text-xs text-muted-foreground mb-4 flex items-center gap-1.5 bg-muted/50 rounded-md px-3 py-2">
                      <HelpTip content="注册成功后不会自动登录，需要返回「账号登录」标签，使用刚注册的用户名和密码手动登录。" side="bottom" />
                      注册成功后，请切换到「账号登录」标签重新登录
                    </p>
                    <Form {...registerForm}>
                      <form onSubmit={registerForm.handleSubmit(onRegister)} className="space-y-4">
                        <FormField
                          control={registerForm.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-normal">用户名</FormLabel>
                              <FormControl>
                                <Input placeholder="字母、数字、下划线，3-20位" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={registerForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-normal">密码</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="至少8位" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={registerForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-normal">确认密码</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="再次输入密码" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={registerForm.control}
                          name="agreement"
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex items-start gap-2 min-h-12">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                    className="mt-0.5"
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-tight">
                                  <FormLabel className="text-sm font-normal text-muted-foreground cursor-pointer">
                                    我已阅读并同意{' '}
                                    <span className="text-primary underline-offset-2 underline">用户协议</span>
                                    {' '}和{' '}
                                    <span className="text-primary underline-offset-2 underline">隐私政策</span>
                                  </FormLabel>
                                  <FormMessage />
                                </div>
                              </div>
                            </FormItem>
                          )}
                        />
                        <Button type="submit" className="w-full" disabled={isLoading}>
                          {isLoading ? '注册中...' : '注册账号'}
                        </Button>
                      </form>
                    </Form>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

