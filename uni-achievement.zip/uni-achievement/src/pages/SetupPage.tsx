import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { EDUCATION_LEVELS, STUDY_YEARS_OPTIONS } from '@/types/types';
import { GraduationCap, ChevronRight } from 'lucide-react';

const profileSchema = z.object({
  name: z.string().min(1, '请输入姓名').max(30, '姓名不超过30字'),
  school: z.string().min(1, '请输入学校名称'),
  student_id: z.string().optional(),
  enrollment_year: z
    .number({ invalid_type_error: '请输入入学年份' })
    .min(2000, '年份不能早于2000年')
    .max(new Date().getFullYear(), '年份不能超过当前年份'),
  study_years: z.number({ invalid_type_error: '请选择学制' }),
  education_level: z.string().min(1, '请选择学历层次'),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function SetupPage() {
  const { user, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState(1);

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: '',
      school: '',
      student_id: '',
      enrollment_year: new Date().getFullYear(),
      study_years: 4,
      education_level: '本科',
    },
  });

  const currentYear = new Date().getFullYear();
  const enrollmentYear = form.watch('enrollment_year');
  const educationLevel = form.watch('education_level');
  const studyYears = form.watch('study_years');

  // 计算当前年级
  const calcCurrentGrade = () => {
    if (!enrollmentYear) return null;
    const now = new Date();
    const refYear = now.getMonth() >= 8 ? now.getFullYear() : now.getFullYear() - 1;
    const grade = refYear - enrollmentYear + 1;
    if (grade < 1) return null;
    if (educationLevel === '本科') {
      const labels = ['大一', '大二', '大三', '大四', '大五', '大六'];
      return labels[grade - 1] || `大${grade}`;
    } else if (educationLevel === '硕士') {
      const labels = ['研一', '研二', '研三'];
      return labels[grade - 1] || `研${grade}`;
    } else if (educationLevel === '博士') {
      return `博${grade}`;
    }
    return `第${grade}年级`;
  };

  const onSubmit = async (values: ProfileFormValues) => {
    if (!user) return;
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          name: values.name,
          school: values.school,
          student_id: values.student_id || null,
          enrollment_year: values.enrollment_year,
          study_years: values.study_years,
          education_level: values.education_level,
          profile_completed: true,
        })
        .eq('id', user.id);

      if (error) throw error;
      await refreshProfile();
      toast.success('档案设置完成，开始你的成就之旅！');
      navigate('/');
    } catch (err) {
      toast.error(`保存失败：${err instanceof Error ? err.message : '未知错误'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSkip = () => {
    navigate('/');
  };

  const currentGrade = calcCurrentGrade();
  const graduationYear =
    enrollmentYear && studyYears ? enrollmentYear + studyYears : null;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        {/* 头部 */}
        <div className="text-center mb-8">
          <div className="w-14 h-14 bg-primary rounded-xl flex items-center justify-center mx-auto mb-4">
            <GraduationCap className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold text-foreground text-balance mb-2">完善基础档案</h1>
          <p className="text-muted-foreground text-sm text-pretty">
            填写你的学籍信息，帮助系统自动匹配年级和分类
          </p>
        </div>

        {/* 进度条 */}
        <div className="mb-6">
          <div className="flex justify-between text-xs text-muted-foreground mb-2">
            <span>基础信息</span>
            <span>学籍信息</span>
          </div>
          <Progress value={step === 1 ? 50 : 100} className="h-1.5" />
        </div>

        <Card className="border-border">
          <CardHeader className="pb-4">
            <CardTitle className="text-base text-balance">
              {step === 1 ? '步骤一：基础信息' : '步骤二：学籍信息'}
            </CardTitle>
            <CardDescription className="text-pretty">
              {step === 1
                ? '填写你的姓名和学校信息'
                : '填写入学年份和学制，系统将自动计算年级'}
            </CardDescription>
          </CardHeader>

          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                {step === 1 && (
                  <>
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-normal">姓名 *</FormLabel>
                          <FormControl>
                            <Input placeholder="请输入真实姓名" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="school"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-normal">学校 *</FormLabel>
                          <FormControl>
                            <Input placeholder="请输入就读学校名称" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="student_id"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-normal">学号（可选）</FormLabel>
                          <FormControl>
                            <Input placeholder="请输入学号" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button
                      type="button"
                      className="w-full"
                      onClick={() => {
                        form.trigger(['name', 'school']).then((valid) => {
                          if (valid) setStep(2);
                        });
                      }}
                    >
                      下一步
                      <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                  </>
                )}

                {step === 2 && (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="enrollment_year"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-normal">入学年份 *</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                min={2000}
                                max={currentYear}
                                placeholder={`${currentYear}`}
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="study_years"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-normal">学制 *</FormLabel>
                            <Select
                              value={String(field.value)}
                              onValueChange={(v) => field.onChange(parseInt(v))}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="选择学制" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {STUDY_YEARS_OPTIONS.map((opt) => (
                                  <SelectItem key={opt.value} value={String(opt.value)}>
                                    {opt.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="education_level"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-normal">学历层次 *</FormLabel>
                          <Select value={field.value} onValueChange={field.onChange}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="选择学历" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {EDUCATION_LEVELS.map((opt) => (
                                <SelectItem key={opt.value} value={opt.value}>
                                  {opt.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* 年级预览 */}
                    {currentGrade && (
                      <div className="rounded p-3 bg-[hsl(35_90%_55%/0.08)] border border-[hsl(35_90%_55%/0.3)]">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">当前年级</span>
                          <span className="font-medium text-foreground">{currentGrade}</span>
                        </div>
                        {graduationYear && (
                          <div className="flex justify-between text-sm mt-1">
                            <span className="text-muted-foreground">预计毕业年份</span>
                            <span className="font-medium text-foreground">{graduationYear} 年</span>
                          </div>
                        )}
                      </div>
                    )}

                    <div className="flex gap-3">
                      <Button
                        type="button"
                        variant="outline"
                        className="flex-1"
                        onClick={() => setStep(1)}
                      >
                        上一步
                      </Button>
                      <Button type="submit" className="flex-1" disabled={isLoading}>
                        {isLoading ? '保存中...' : '完成设置'}
                      </Button>
                    </div>
                  </>
                )}
              </form>
            </Form>
          </CardContent>
        </Card>

        <div className="text-center mt-4">
          <button
            type="button"
            onClick={handleSkip}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors underline underline-offset-2"
          >
            跳过，稍后再设置
          </button>
        </div>
      </div>
    </div>
  );
}
