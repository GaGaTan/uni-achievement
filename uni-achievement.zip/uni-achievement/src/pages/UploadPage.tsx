import { useState, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from 'sonner';
import { useDropzone } from 'react-dropzone';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import {
  ACHIEVEMENT_CATEGORIES,
  HONOR_SUBCATEGORIES,
  COMPETITION_SUBCATEGORIES,
  VOLUNTEER_SUBCATEGORIES,
  ACADEMIC_SUBCATEGORIES,
  STUDENT_WORK_SUBCATEGORIES,
  CERTIFICATE_SUBCATEGORIES,
  ACHIEVEMENT_LEVELS,
  SCENE_TAGS,
  calcGradeYear,
} from '@/types/types';
import type { AIAnalysisResult } from '@/types/types';
import {
  Upload,
  X,
  Sparkles,
  CheckCircle,
  AlertCircle,
  Image,
  ChevronRight,
  FileText,
  Lock,
  Eye,
  EyeOff,
  RotateCw,
  RotateCcw,
  Sun,
  Contrast,
  Link2,
  Plus,
  Pencil,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { HelpTip, TipBanner } from '@/components/common/HelpTip';

// ────────── 工具函数 ──────────

// 图片压缩（超1MB时压缩至WEBP格式）
async function compressImage(file: File): Promise<{ file: File; compressed: boolean; finalSize: number }> {
  const MAX_SIZE = 1024 * 1024;
  if (file.size <= MAX_SIZE) return { file, compressed: false, finalSize: file.size };
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    const img = new window.Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      let { width, height } = img;
      const MAX_DIM = 1920;
      if (width > MAX_DIM || height > MAX_DIM) {
        const ratio = Math.min(MAX_DIM / width, MAX_DIM / height);
        width = Math.round(width * ratio);
        height = Math.round(height * ratio);
      }
      canvas.width = width; canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) { resolve({ file, compressed: false, finalSize: file.size }); return; }
      ctx.drawImage(img, 0, 0, width, height);
      let quality = 0.8;
      const tryCompress = () => {
        canvas.toBlob((blob) => {
          if (!blob) { resolve({ file, compressed: false, finalSize: file.size }); return; }
          if (blob.size <= MAX_SIZE || quality <= 0.3) {
            resolve({ file: new File([blob], file.name.replace(/\.[^.]+$/, '.webp'), { type: 'image/webp' }), compressed: true, finalSize: blob.size });
          } else { quality -= 0.1; tryCompress(); }
        }, 'image/webp', quality);
      };
      tryCompress();
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve({ file, compressed: false, finalSize: file.size }); };
    img.src = url;
  });
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function getSubcategories(category: string) {
  switch (category) {
    case '荣誉奖项': return HONOR_SUBCATEGORIES;
    case '赛事竞赛': return COMPETITION_SUBCATEGORIES;
    case '志愿实践': return VOLUNTEER_SUBCATEGORIES;
    case '学术成果': return ACADEMIC_SUBCATEGORIES;
    case '学生工作': return STUDENT_WORK_SUBCATEGORIES;
    case '个人证件': return CERTIFICATE_SUBCATEGORIES;
    default: return [];
  }
}

// 简单客户端加密（btoa + 反转）
function encryptText(text: string): string {
  return btoa(text.split('').reverse().join(''));
}
function decryptText(encrypted: string): string {
  try { return atob(encrypted).split('').reverse().join(''); } catch { return encrypted; }
}

// 获取文件icon
function getFileTypeIcon(fileType: string) {
  if (fileType === 'pdf') return '📄';
  if (fileType === 'word') return '📝';
  if (fileType === 'excel') return '📊';
  if (fileType === 'link') return '🔗';
  return '🖼️';
}

// ────────── 类型定义 ──────────

interface UploadItem {
  id: string;
  file: File;
  preview: string;
  fileType: 'image' | 'pdf' | 'word' | 'excel';
  status: 'pending' | 'analyzing' | 'ready' | 'uploading' | 'done' | 'error';
  uploadProgress: number;
  errorMsg?: string;
  aiResult?: AIAnalysisResult;
  name: string;
  category: string;
  subcategory: string;
  level: string;
  achieved_at: string;
  tags: string[];
  notes: string;
  isPrivate: boolean;
  certificate_size?: '1inch' | '2inch';
  certificate_bg?: 'white' | 'blue' | 'red';
  volunteerHours?: string;
  // 图片编辑参数
  rotation: number;
  brightness: number;
  contrast: number;
}

interface LinkItem {
  id: string;
  url: string;
  name: string;
  category: string;
  notes: string;
  status: 'pending' | 'saving' | 'done' | 'error';
}

interface AccountItem {
  id: string;
  platform_name: string;
  username: string;
  password: string;
  notes: string;
  status: 'pending' | 'saving' | 'done' | 'error';
}

// ────────── 主页面 ──────────

export default function UploadPage() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  // 图片/文件上传
  const [items, setItems] = useState<UploadItem[]>([]);
  const [isBatchAnalyzing, setIsBatchAnalyzing] = useState(false);
  const [batchProgress, setBatchProgress] = useState(0);
  const [isBatchSaving, setIsBatchSaving] = useState(false);

  // 链接上传
  const [linkItems, setLinkItems] = useState<LinkItem[]>([]);
  const [newLinkUrl, setNewLinkUrl] = useState('');
  const [newLinkName, setNewLinkName] = useState('');

  // 私密账号录入
  const [accountItems, setAccountItems] = useState<AccountItem[]>([]);

  // 重复检测弹窗
  const [duplicateAlert, setDuplicateAlert] = useState<{ show: boolean; itemId: string; existingName: string }>({ show: false, itemId: '', existingName: '' });

  // 图片编辑弹窗
  const [editingItemId, setEditingItemId] = useState<string | null>(null);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const newItems: UploadItem[] = [];
    for (const file of acceptedFiles) {
      const isImg = file.type.startsWith('image/');
      const ext = file.name.split('.').pop()?.toLowerCase() || '';
      let fileType: UploadItem['fileType'] = 'image';
      if (!isImg) {
        if (ext === 'pdf') fileType = 'pdf';
        else if (['doc', 'docx'].includes(ext)) fileType = 'word';
        else if (['xls', 'xlsx'].includes(ext)) fileType = 'excel';
      }
      const preview = isImg ? URL.createObjectURL(file) : '';
      newItems.push({
        id: crypto.randomUUID(), file, preview, fileType,
        status: 'pending', uploadProgress: 0,
        name: '', category: '', subcategory: '', level: '',
        achieved_at: '', tags: [], notes: '', isPrivate: false,
        rotation: 0, brightness: 100, contrast: 100,
      });
    }
    setItems((prev) => [...prev, ...newItems]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/gif': ['.gif'],
      'image/webp': ['.webp'],
      'image/avif': ['.avif'],
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/vnd.ms-excel': ['.xls'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
    },
    maxFiles: 20,
  });

  const removeItem = (id: string) => {
    setItems((prev) => {
      const item = prev.find((i) => i.id === id);
      if (item?.preview) URL.revokeObjectURL(item.preview);
      return prev.filter((i) => i.id !== id);
    });
  };

  const updateItem = (id: string, updates: Partial<UploadItem>) => {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...updates } : i)));
  };

  // AI分析
  const analyzeItem = async (item: UploadItem) => {
    updateItem(item.id, { status: 'analyzing' });
    try {
      const filename = item.file.name;
      const fileExt = filename.split('.').pop()?.toLowerCase() || '';
      const isPdf = fileExt === 'pdf';
      const isDoc = ['doc', 'docx', 'xls', 'xlsx'].includes(fileExt);

      if (isPdf || isDoc) {
        // 文档类材料：调用edge function用文件名推断分类
        const { data, error } = await supabase.functions.invoke<AIAnalysisResult>('analyze-achievement', {
          body: { filename, file_type: fileExt },
        });
        if (error || !data) {
          // 降级：仅用文件名
          updateItem(item.id, {
            status: 'ready',
            name: filename.replace(/\.[^.]+$/, ''),
            category: '其他',
          });
          return;
        }
        updateItem(item.id, {
          status: 'ready', aiResult: data,
          name: data.suggested_name || filename.replace(/\.[^.]+$/, ''),
          category: data.suggested_category || '其他',
          subcategory: data.suggested_subcategory || '',
          level: data.suggested_level || '',
          achieved_at: data.suggested_date || '',
        });
        return;
      }

      if (item.fileType !== 'image') {
        updateItem(item.id, { status: 'ready', name: filename.replace(/\.[^.]+$/, '') });
        return;
      }

      const { file: processedFile } = await compressImage(item.file);
      const base64 = await fileToBase64(processedFile);
      const { data, error } = await supabase.functions.invoke<AIAnalysisResult>('analyze-achievement', { body: { image_base64: base64, filename } });
      if (error) {
        const errMsg = await error?.context?.text?.();
        throw new Error(errMsg || error.message);
      }
      if (!data) throw new Error('AI分析未返回结果');
      updateItem(item.id, {
        status: 'ready', aiResult: data,
        name: data.suggested_name || '',
        category: data.suggested_category || '',
        subcategory: data.suggested_subcategory || '',
        level: data.suggested_level || '',
        achieved_at: data.suggested_date || '',
      });
    } catch (err) {
      updateItem(item.id, {
        status: 'error',
        errorMsg: err instanceof Error ? err.message : 'AI识别失败',
        name: `未命名材料-${new Date().toISOString().slice(0, 10)}`,
        category: '其他',
      });
    }
  };

  const analyzeAll = async () => {
    const pendingItems = items.filter((i) => i.status === 'pending');
    if (pendingItems.length === 0) return;
    setIsBatchAnalyzing(true); setBatchProgress(0);
    for (let i = 0; i < pendingItems.length; i++) {
      await analyzeItem(pendingItems[i]);
      setBatchProgress(Math.round(((i + 1) / pendingItems.length) * 100));
    }
    setIsBatchAnalyzing(false);
    toast.success(`AI识别完成，共处理 ${pendingItems.length} 个文件`);
  };

  const playSuccessSound = () => {
    if (!profile?.sound_reminder) return;
    try {
      const audioCtx = new (window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain); gain.connect(audioCtx.destination);
      osc.frequency.setValueAtTime(880, audioCtx.currentTime);
      osc.frequency.setValueAtTime(1100, audioCtx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.4);
      osc.start(audioCtx.currentTime); osc.stop(audioCtx.currentTime + 0.4);
    } catch (_e) { /* 铃声不影响主流程 */ }
  };

  const archiveItem = async (item: UploadItem): Promise<boolean> => {
    if (!user || !item.name) return false;
    updateItem(item.id, { status: 'uploading', uploadProgress: 10 });
    try {
      let imageUrl = '';
      let imagePath = '';
      let fileUrl: string | null = null;
      let filePath: string | null = null;

      if (item.fileType === 'image') {
        // 应用图片编辑（旋转+亮度对比度）
        let processedFile = item.file;
        if (item.rotation !== 0 || item.brightness !== 100 || item.contrast !== 100) {
          processedFile = await applyImageEdits(item.file, item.rotation, item.brightness, item.contrast);
        }
        const { file: compressed, compressed: wasCompressed, finalSize } = await compressImage(processedFile);
        if (wasCompressed) toast.info(`图片已自动压缩，最终大小：${(finalSize / 1024).toFixed(0)}KB`);
        updateItem(item.id, { uploadProgress: 30 });
        const ext = compressed.name.split('.').pop() || 'webp';
        const fileName = `${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
        imagePath = `${user.id}/${fileName}`;
        const { error: uploadError } = await supabase.storage.from('achievements').upload(imagePath, compressed, { upsert: false });
        if (uploadError) throw uploadError;
        const { data: urlData } = supabase.storage.from('achievements').getPublicUrl(imagePath);
        imageUrl = urlData.publicUrl;
      } else {
        updateItem(item.id, { uploadProgress: 30 });
        const ext = item.file.name.split('.').pop() || 'bin';
        const fileName = `${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
        filePath = `${user.id}/files/${fileName}`;
        const { error: uploadError } = await supabase.storage.from('achievements').upload(filePath, item.file, { upsert: false });
        if (uploadError) throw uploadError;
        const { data: urlData } = supabase.storage.from('achievements').getPublicUrl(filePath);
        fileUrl = urlData.publicUrl;
      }

      updateItem(item.id, { uploadProgress: 70 });

      let gradeYear: number | null = null;
      if (profile?.enrollment_year && item.achieved_at) gradeYear = calcGradeYear(profile.enrollment_year, item.achieved_at);
      else if (profile?.enrollment_year) gradeYear = calcGradeYear(profile.enrollment_year);

      const { error: dbError } = await supabase.from('achievements').insert({
        user_id: user.id,
        name: item.name,
        category: item.category || '其他',
        subcategory: item.subcategory || null,
        level: item.level || null,
        grade_year: gradeYear,
        achieved_at: item.achieved_at || null,
        image_url: imageUrl,
        image_path: imagePath,
        file_type: item.fileType,
        file_url: fileUrl,
        file_path: filePath,
        tags: item.tags,
        is_private: item.isPrivate,
        notes: item.notes || null,
        volunteer_hours: item.volunteerHours ? parseFloat(item.volunteerHours) : null,
        certificate_size: item.certificate_size || null,
        certificate_bg: item.certificate_bg || null,
        ai_description: item.aiResult?.description || null,
        ai_keywords: item.aiResult?.keywords || null,
      });
      if (dbError) throw dbError;

      updateItem(item.id, { status: 'done', uploadProgress: 100 });
      return true;
    } catch (err) {
      updateItem(item.id, { status: 'error', errorMsg: err instanceof Error ? err.message : '归档失败' });
      return false;
    }
  };

  const archiveAll = async () => {
    const readyItems = items.filter((i) => (i.status === 'ready' || i.status === 'error') && i.name);
    if (readyItems.length === 0) { toast.error('没有可归档的材料，请先进行AI识别或填写材料名称'); return; }
    setIsBatchSaving(true);
    let successCount = 0;
    for (const item of readyItems) { const ok = await archiveItem(item); if (ok) successCount++; }
    setIsBatchSaving(false);
    if (successCount > 0) {
      playSuccessSound();
      toast.success(`🎉 成功归档 ${successCount} 个材料！`);
      setTimeout(() => navigate('/'), 1500);
    } else { toast.error('归档失败，请检查网络连接后重试'); }
  };

  // 保存链接
  const saveLinkItem = async (item: LinkItem) => {
    if (!user || !item.url || !item.name) return;
    setLinkItems((prev) => prev.map((i) => i.id === item.id ? { ...i, status: 'saving' } : i));
    try {
      const { error } = await supabase.from('achievements').insert({
        user_id: user.id, name: item.name, category: item.category || '其他',
        image_url: '', image_path: '', file_type: 'link', file_url: item.url,
        notes: item.notes || null,
      });
      if (error) throw error;
      setLinkItems((prev) => prev.map((i) => i.id === item.id ? { ...i, status: 'done' } : i));
      playSuccessSound();
      toast.success('链接已归档');
    } catch (err) {
      setLinkItems((prev) => prev.map((i) => i.id === item.id ? { ...i, status: 'error' } : i));
      toast.error('归档失败');
    }
  };

  // 保存账号密码
  const saveAccountItem = async (item: AccountItem) => {
    if (!user || !item.platform_name || !item.username || !item.password) {
      toast.error('请填写完整的平台名称、账号和密码');
      return;
    }
    setAccountItems((prev) => prev.map((i) => i.id === item.id ? { ...i, status: 'saving' } : i));
    try {
      const { error } = await supabase.from('account_secrets').insert({
        user_id: user.id,
        platform_name: item.platform_name,
        username_encrypted: encryptText(item.username),
        password_encrypted: encryptText(item.password),
        notes: item.notes || null,
      });
      if (error) throw error;
      setAccountItems((prev) => prev.map((i) => i.id === item.id ? { ...i, status: 'done' } : i));
      playSuccessSound();
      toast.success(`"${item.platform_name}" 账号已加密保存`);
    } catch (err) {
      setAccountItems((prev) => prev.map((i) => i.id === item.id ? { ...i, status: 'error' } : i));
      toast.error('保存失败');
    }
  };

  const addLinkItem = () => {
    if (!newLinkUrl.trim()) { toast.error('请输入链接地址'); return; }
    setLinkItems((prev) => [...prev, {
      id: crypto.randomUUID(), url: newLinkUrl.trim(),
      name: newLinkName.trim() || new URL(newLinkUrl).hostname, category: '', notes: '', status: 'pending',
    }]);
    setNewLinkUrl(''); setNewLinkName('');
  };

  const addAccountItem = () => {
    setAccountItems((prev) => [...prev, {
      id: crypto.randomUUID(), platform_name: '', username: '', password: '', notes: '', status: 'pending',
    }]);
  };

  const pendingCount = items.filter((i) => i.status === 'pending').length;
  const readyCount = items.filter((i) => i.status === 'ready').length;
  const errorCount = items.filter((i) => i.status === 'error').length;
  const doneCount = items.filter((i) => i.status === 'done').length;

  const editingItem = items.find((i) => i.id === editingItemId);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-foreground text-balance">资料归档</h1>
        <p className="text-sm text-muted-foreground mt-1 text-pretty">
          上传图片、文件材料，或录入链接和账号密码，AI自动识别并归档
        </p>
      </div>

      <TipBanner>
        <strong>使用说明：</strong>选择归档方式 → 上传材料 → 等待AI自动识别分类 → 确认或修改信息 → 点击"归档"保存。
        <br />人像照片会自动识别人脸数量：<strong>单人脸</strong>归为证件照，<strong>多人脸</strong>归为合照。
      </TipBanner>

      <Tabs defaultValue="files">
        <TabsList className="mb-4">
          <TabsTrigger value="files">
            <Upload className="w-4 h-4 mr-1.5" />
            上传图片/文件
          </TabsTrigger>
          <TabsTrigger value="link">
            <Link2 className="w-4 h-4 mr-1.5" />
            链接归档
          </TabsTrigger>
          <TabsTrigger value="account">
            <Lock className="w-4 h-4 mr-1.5" />
            账号密码
          </TabsTrigger>
        </TabsList>

        {/* ── 图片/文件上传 Tab ── */}
        <TabsContent value="files" className="space-y-4">
          <Card className="border-border">
            <CardContent className="p-6">
              <div
                {...getRootProps()}
                className={cn(
                  'border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors',
                  isDragActive ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50 hover:bg-muted/30'
                )}
              >
                <input {...getInputProps()} />
                <Upload className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <p className="font-medium text-foreground text-sm mb-1">
                  {isDragActive ? '松开以上传文件' : '拖拽文件到此处，或点击选择文件'}
                </p>
                <p className="text-xs text-muted-foreground">
                  支持图片（JPG/PNG/WEBP）、PDF、Word、Excel，最多同时上传 20 个
                </p>
                <p className="text-xs text-muted-foreground mt-1">超过 1MB 的图片将自动压缩</p>
              </div>
            </CardContent>
          </Card>

          {items.length > 0 && (
            <>
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2 text-sm">
                  <span className="text-muted-foreground">共 {items.length} 个文件</span>
                  {pendingCount > 0 && <Badge variant="secondary">{pendingCount} 待识别</Badge>}
                  {readyCount > 0 && <Badge className="bg-[hsl(142_70%_40%)] text-white hover:bg-[hsl(142_70%_40%)]">{readyCount} 已识别</Badge>}
                  {errorCount > 0 && <Badge variant="destructive">{errorCount} 识别失败</Badge>}
                  {doneCount > 0 && <Badge className="bg-primary text-primary-foreground hover:bg-primary">{doneCount} 已归档</Badge>}
                </div>
                <div className="flex gap-2">
                  {pendingCount > 0 && (
                    <Button variant="outline" size="sm" onClick={analyzeAll} disabled={isBatchAnalyzing}>
                      <Sparkles className="w-4 h-4 mr-1.5" />
                      {isBatchAnalyzing ? `识别中... ${batchProgress}%` : `AI识别 (${pendingCount})`}
                    </Button>
                  )}
                  <HelpTip
                    content="点击「AI识别」自动分析材料内容、提取奖项名称/日期/单位等信息，并智能归类。识别完成后可手动修改任意字段。人像照片会自动识别人脸数量：单人脸→证件照，多人脸→合照。"
                    side="top"
                    maxWidth="280px"
                  />
                  {(readyCount > 0 || errorCount > 0) && (
                    <Button size="sm" onClick={archiveAll} disabled={isBatchSaving}>
                      <CheckCircle className="w-4 h-4 mr-1.5" />
                      {isBatchSaving ? '归档中...' : `确认归档 (${readyCount + errorCount})`}
                    </Button>
                  )}
                </div>
              </div>

              {isBatchAnalyzing && (
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>AI正在识别材料...</span>
                    <span>{batchProgress}%</span>
                  </div>
                  <Progress value={batchProgress} className="h-1.5" />
                </div>
              )}

              <div className="space-y-3">
                {items.map((item) => (
                  <UploadItemCard
                    key={item.id}
                    item={item}
                    onRemove={() => removeItem(item.id)}
                    onAnalyze={() => analyzeItem(item)}
                    onUpdate={(updates) => updateItem(item.id, updates)}
                    onEdit={() => setEditingItemId(item.id)}
                    onArchive={() => archiveItem(item)}
                  />
                ))}
              </div>
            </>
          )}

          {items.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <Image className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm">暂无上传文件，请选择或拖拽文件</p>
            </div>
          )}
        </TabsContent>

        {/* ── 链接归档 Tab ── */}
        <TabsContent value="link" className="space-y-4">
          <TipBanner>
            <strong>链接归档：</strong>适合归档在线证书、网页通知、论文链接等。填入链接地址并填写名称和分类后，系统会将链接与对应分类一同保存，方便日后检索。
          </TipBanner>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">添加链接</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1 md:col-span-2">
                  <Label className="text-xs font-normal text-muted-foreground">链接地址 *</Label>
                  <Input
                    value={newLinkUrl}
                    onChange={(e) => setNewLinkUrl(e.target.value)}
                    placeholder="https://..."
                    className="text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-normal text-muted-foreground">链接名称</Label>
                  <Input
                    value={newLinkName}
                    onChange={(e) => setNewLinkName(e.target.value)}
                    placeholder="如：某竞赛获奖公示"
                    className="text-sm"
                  />
                </div>
                <div className="flex items-end">
                  <Button onClick={addLinkItem} className="w-full">
                    <Plus className="w-4 h-4 mr-1.5" />
                    添加链接
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {linkItems.length > 0 && (
            <div className="space-y-3">
              {linkItems.map((item) => (
                <LinkItemCard
                  key={item.id}
                  item={item}
                  onSave={() => saveLinkItem(item)}
                  onUpdate={(updates) => setLinkItems((prev) => prev.map((i) => i.id === item.id ? { ...i, ...updates } : i))}
                  onRemove={() => setLinkItems((prev) => prev.filter((i) => i.id !== item.id))}
                />
              ))}
            </div>
          )}

          {linkItems.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <Link2 className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm">添加链接后在此处显示，可归档公示文件、电子证书等</p>
            </div>
          )}
        </TabsContent>

        {/* ── 账号密码 Tab ── */}
        <TabsContent value="account" className="space-y-4">
          <TipBanner>
            <strong>账号密码归档：</strong>安全存储校园系统、学习平台、竞赛网站等账号密码。数据加密存储，仅您本人可查看。填写平台名称、账号、密码后点击「保存」即可完成归档。
          </TipBanner>
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              <Lock className="w-4 h-4 inline mr-1 align-middle" />
              账号密码经客户端加密后存储，仅您本人可查看
            </p>
            <Button size="sm" onClick={addAccountItem}>
              <Plus className="w-4 h-4 mr-1.5" />
              新增账号
            </Button>
          </div>

          {accountItems.length > 0 && (
            <div className="space-y-3">
              {accountItems.map((item) => (
                <AccountItemCard
                  key={item.id}
                  item={item}
                  onSave={() => saveAccountItem(item)}
                  onUpdate={(updates) => setAccountItems((prev) => prev.map((i) => i.id === item.id ? { ...i, ...updates } : i))}
                  onRemove={() => setAccountItems((prev) => prev.filter((i) => i.id !== item.id))}
                />
              ))}
            </div>
          )}

          {accountItems.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <Lock className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm">点击"新增账号"录入校园软件、学习平台等账号密码</p>
              <p className="text-xs mt-1 text-muted-foreground/70">加密存储，安全可靠</p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* 重复检测弹窗 */}
      <AlertDialog open={duplicateAlert.show} onOpenChange={(open) => !open && setDuplicateAlert({ show: false, itemId: '', existingName: '' })}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>检测到重复材料</AlertDialogTitle>
            <AlertDialogDescription>
              系统检测到与"<strong>{duplicateAlert.existingName}</strong>"相似的材料已存在，请选择处理方式。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => { removeItem(duplicateAlert.itemId); setDuplicateAlert({ show: false, itemId: '', existingName: '' }); }}>
              忽略（不归档）
            </AlertDialogCancel>
            <AlertDialogAction onClick={() => setDuplicateAlert({ show: false, itemId: '', existingName: '' })}>
              继续归档（新版本）
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 图片编辑弹窗 */}
      {editingItem && (
        <ImageEditorDialog
          item={editingItem}
          onClose={() => setEditingItemId(null)}
          onSave={(updates) => { updateItem(editingItem.id, updates); setEditingItemId(null); }}
        />
      )}
    </div>
  );
}

// ────────── 图片编辑弹窗 ──────────

interface ImageEditorDialogProps {
  item: UploadItem;
  onClose: () => void;
  onSave: (updates: Partial<UploadItem>) => void;
}

function ImageEditorDialog({ item, onClose, onSave }: ImageEditorDialogProps) {
  const [rotation, setRotation] = useState(item.rotation);
  const [brightness, setBrightness] = useState(item.brightness);
  const [contrast, setContrast] = useState(item.contrast);

  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
        <DialogHeader>
          <DialogTitle>编辑图片</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          {/* 预览 */}
          <div className="flex justify-center bg-muted rounded-lg overflow-hidden" style={{ minHeight: 200 }}>
            <img
              src={item.preview}
              alt="预览"
              style={{
                transform: `rotate(${rotation}deg)`,
                filter: `brightness(${brightness}%) contrast(${contrast}%)`,
                maxHeight: 300,
                objectFit: 'contain',
                transition: 'all 0.2s',
              }}
            />
          </div>

          {/* 控制面板 */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* 旋转 */}
            <div className="space-y-2">
              <Label className="text-xs font-normal text-muted-foreground flex items-center gap-1">
                <RotateCw className="w-3 h-3" /> 旋转（{rotation}°）
              </Label>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1" onClick={() => setRotation((r) => r - 90)}>
                  <RotateCcw className="w-4 h-4 mr-1" />逆时针
                </Button>
                <Button variant="outline" size="sm" className="flex-1" onClick={() => setRotation((r) => r + 90)}>
                  <RotateCw className="w-4 h-4 mr-1" />顺时针
                </Button>
              </div>
            </div>

            {/* 亮度 */}
            <div className="space-y-2">
              <Label className="text-xs font-normal text-muted-foreground flex items-center gap-1">
                <Sun className="w-3 h-3" /> 亮度（{brightness}%）
              </Label>
              <Slider min={50} max={200} step={5} value={[brightness]} onValueChange={([v]) => setBrightness(v)} />
            </div>

            {/* 对比度 */}
            <div className="space-y-2">
              <Label className="text-xs font-normal text-muted-foreground flex items-center gap-1">
                <Contrast className="w-3 h-3" /> 对比度（{contrast}%）
              </Label>
              <Slider min={50} max={200} step={5} value={[contrast]} onValueChange={([v]) => setContrast(v)} />
            </div>

            {/* 重置 */}
            <div className="flex items-end">
              <Button variant="outline" size="sm" className="w-full" onClick={() => { setRotation(0); setBrightness(100); setContrast(100); }}>
                重置
              </Button>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onClose}>取消</Button>
            <Button onClick={() => onSave({ rotation, brightness, contrast })}>保存调整</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// 应用图片编辑到 canvas
async function applyImageEdits(file: File, rotation: number, brightness: number, contrast: number): Promise<File> {
  return new Promise((resolve) => {
    const img = new window.Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      const rad = (rotation * Math.PI) / 180;
      const cos = Math.abs(Math.cos(rad));
      const sin = Math.abs(Math.sin(rad));
      const w = Math.round(img.width * cos + img.height * sin);
      const h = Math.round(img.width * sin + img.height * cos);
      const canvas = document.createElement('canvas');
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d')!;
      ctx.filter = `brightness(${brightness}%) contrast(${contrast}%)`;
      ctx.translate(w / 2, h / 2);
      ctx.rotate(rad);
      ctx.drawImage(img, -img.width / 2, -img.height / 2);
      canvas.toBlob((blob) => {
        if (!blob) { resolve(file); return; }
        resolve(new File([blob], file.name, { type: file.type || 'image/jpeg' }));
      }, file.type || 'image/jpeg', 0.9);
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve(file); };
    img.src = url;
  });
}

// ────────── 上传材料卡片 ──────────

interface UploadItemCardProps {
  item: UploadItem;
  onRemove: () => void;
  onAnalyze: () => void;
  onUpdate: (updates: Partial<UploadItem>) => void;
  onEdit: () => void;
  onArchive: () => void;
}

function UploadItemCard({ item, onRemove, onAnalyze, onUpdate, onEdit, onArchive }: UploadItemCardProps) {
  const subcategoryOptions = getSubcategories(item.category);

  const statusConfig = {
    pending: { color: 'text-muted-foreground', label: '待识别' },
    analyzing: { color: 'text-[hsl(35_90%_45%)]', label: 'AI识别中...' },
    ready: { color: 'text-[hsl(142_70%_40%)]', label: '识别完成' },
    uploading: { color: 'text-primary', label: '归档中...' },
    done: { color: 'text-[hsl(142_70%_40%)]', label: '已归档' },
    error: { color: 'text-destructive', label: '识别失败' },
  };
  const sc = statusConfig[item.status];

  return (
    <Card className={cn('border-border', item.status === 'done' && 'opacity-60')}>
      <CardContent className="p-4">
        <div className="flex gap-4">
          {/* 预览区 */}
          <div className="w-20 h-20 rounded overflow-hidden shrink-0 bg-muted relative">
            {item.fileType === 'image' && item.preview ? (
              <>
                <img
                  src={item.preview}
                  alt="材料预览"
                  className="w-full h-full object-cover"
                  style={{
                    transform: `rotate(${item.rotation}deg)`,
                    filter: `brightness(${item.brightness}%) contrast(${item.contrast}%)`,
                  }}
                />
                {item.status === 'analyzing' && <div className="absolute inset-0 ai-scanning" />}
              </>
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center gap-1">
                <span className="text-2xl">{getFileTypeIcon(item.fileType)}</span>
                <span className="text-xs text-muted-foreground uppercase">{item.fileType}</span>
              </div>
            )}
          </div>

          {/* 内容区 */}
          <div className="flex-1 min-w-0 space-y-3">
            {/* 状态行 */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 flex-1 min-w-0">
                {item.status === 'done' ? <CheckCircle className="w-4 h-4 text-[hsl(142_70%_40%)] shrink-0" /> : item.status === 'error' ? <AlertCircle className="w-4 h-4 text-destructive shrink-0" /> : null}
                <span className={cn('text-xs font-medium shrink-0', sc.color)}>{sc.label}</span>
                <span className="text-xs text-muted-foreground truncate">{item.file.name}</span>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {item.status === 'pending' && (
                  <Button size="sm" variant="outline" className="h-7 text-xs px-2" onClick={onAnalyze}>
                    <Sparkles className="w-3 h-3 mr-1" />AI识别
                  </Button>
                )}
                {item.fileType === 'image' && item.status !== 'done' && item.status !== 'uploading' && (
                  <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground" onClick={onEdit} title="编辑图片">
                    <Pencil className="w-3.5 h-3.5" />
                  </Button>
                )}
                {item.status !== 'done' && item.status !== 'uploading' && (
                  <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive" onClick={onRemove}>
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>

            {/* 上传进度 */}
            {item.status === 'uploading' && <Progress value={item.uploadProgress} className="h-1" />}

            {/* 编辑表单 */}
            {(item.status === 'ready' || item.status === 'error' || item.status === 'pending') && (
              <>
                <Separator />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="md:col-span-2 space-y-1">
                    <Label className="text-xs font-normal text-muted-foreground">材料名称 *</Label>
                    <Input value={item.name} onChange={(e) => onUpdate({ name: e.target.value })} placeholder="请输入材料名称" className="h-8 text-sm" />
                  </div>

                  <div className="space-y-1">
                    <Label className="text-xs font-normal text-muted-foreground">分类</Label>
                    <Select value={item.category} onValueChange={(v) => onUpdate({ category: v, subcategory: '' })}>
                      <SelectTrigger className="h-8 text-sm"><SelectValue placeholder="选择分类" /></SelectTrigger>
                      <SelectContent>
                        {ACHIEVEMENT_CATEGORIES.map((c) => (
                          <SelectItem key={c.value} value={c.value}>{c.icon} {c.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {subcategoryOptions.length > 0 && (
                    <div className="space-y-1">
                      <Label className="text-xs font-normal text-muted-foreground">子分类</Label>
                      <Select value={item.subcategory} onValueChange={(v) => onUpdate({ subcategory: v })}>
                        <SelectTrigger className="h-8 text-sm"><SelectValue placeholder="选择子分类" /></SelectTrigger>
                        <SelectContent>
                          {subcategoryOptions.map((c) => (
                            <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {/* 证件照专属选项 */}
                  {item.category === '个人证件' && (
                    <>
                      <div className="space-y-1">
                        <Label className="text-xs font-normal text-muted-foreground">证件照尺寸</Label>
                        <Select value={item.certificate_size || 'none'} onValueChange={(v) => onUpdate({ certificate_size: v === 'none' ? undefined : v as '1inch' | '2inch' })}>
                          <SelectTrigger className="h-8 text-sm"><SelectValue placeholder="选择尺寸" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">未指定</SelectItem>
                            <SelectItem value="1inch">一寸</SelectItem>
                            <SelectItem value="2inch">两寸</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs font-normal text-muted-foreground">底色</Label>
                        <Select value={item.certificate_bg || 'none'} onValueChange={(v) => onUpdate({ certificate_bg: v === 'none' ? undefined : v as 'white' | 'blue' | 'red' })}>
                          <SelectTrigger className="h-8 text-sm"><SelectValue placeholder="选择底色" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">未指定</SelectItem>
                            <SelectItem value="white">白底</SelectItem>
                            <SelectItem value="blue">蓝底</SelectItem>
                            <SelectItem value="red">红底</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </>
                  )}

                  {/* 志愿时长（志愿实践类） */}
                  {item.category === '志愿实践' && (
                    <div className="space-y-1">
                      <Label className="text-xs font-normal text-muted-foreground">志愿时长（小时）</Label>
                      <Input
                        type="number"
                        min="0"
                        step="0.5"
                        value={item.volunteerHours || ''}
                        onChange={(e) => onUpdate({ volunteerHours: e.target.value })}
                        placeholder="如：8"
                        className="h-8 text-sm"
                      />
                    </div>
                  )}

                  <div className="space-y-1">
                    <Label className="text-xs font-normal text-muted-foreground">奖项等级</Label>
                    <Select value={item.level || 'none'} onValueChange={(v) => onUpdate({ level: v === 'none' ? '' : v })}>
                      <SelectTrigger className="h-8 text-sm"><SelectValue placeholder="选择等级" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">无</SelectItem>
                        {ACHIEVEMENT_LEVELS.map((l) => <SelectItem key={l.value} value={l.value}>{l.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-1">
                    <Label className="text-xs font-normal text-muted-foreground">获得时间</Label>
                    <Input type="date" value={item.achieved_at} onChange={(e) => onUpdate({ achieved_at: e.target.value })} className="h-8 text-sm" />
                  </div>

                  {/* 场景标签 */}
                  <div className="md:col-span-2 space-y-1.5">
                    <Label className="text-xs font-normal text-muted-foreground">场景标签</Label>
                    <div className="flex flex-wrap gap-2">
                      {SCENE_TAGS.map((tag) => (
                        <label key={tag.value} className="flex items-center gap-1 cursor-pointer">
                          <Checkbox
                            checked={item.tags.includes(tag.value)}
                            onCheckedChange={(checked) => {
                              onUpdate({ tags: checked ? [...item.tags, tag.value] : item.tags.filter((t) => t !== tag.value) });
                            }}
                          />
                          <span className="text-xs">{tag.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* 备注 */}
                  <div className="md:col-span-2 space-y-1">
                    <Label className="text-xs font-normal text-muted-foreground">备注</Label>
                    <Textarea
                      value={item.notes}
                      onChange={(e) => onUpdate({ notes: e.target.value })}
                      placeholder="如：实习岗位、工作内容、加分规则等"
                      className="min-h-[60px] text-sm resize-none"
                    />
                  </div>

                  {/* 私密标记 */}
                  <div className="md:col-span-2 flex items-center gap-2">
                    <Checkbox
                      id={`private-${item.id}`}
                      checked={item.isPrivate}
                      onCheckedChange={(checked) => onUpdate({ isPrivate: !!checked })}
                    />
                    <label htmlFor={`private-${item.id}`} className="text-xs text-muted-foreground cursor-pointer flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      标记为私密材料（需二级验证才可查看）
                    </label>
                  </div>
                </div>

                {item.aiResult?.description && (
                  <div className="rounded p-2 bg-muted/50 text-xs text-muted-foreground">
                    <span className="font-medium text-foreground">AI识别：</span>
                    {item.aiResult.description.slice(0, 100)}{item.aiResult.description.length > 100 ? '...' : ''}
                  </div>
                )}

                {(item.status === 'ready' || item.status === 'error') && item.name && (
                  <Button size="sm" className="w-full" onClick={onArchive}>
                    <CheckCircle className="w-4 h-4 mr-1.5" />
                    单独归档此材料
                  </Button>
                )}
              </>
            )}

            {item.status === 'done' && (
              <div className="flex items-center gap-2 text-sm text-[hsl(142_70%_40%)]">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>
                  {item.name} 已成功归档
                  <Link to="/" className="ml-2 text-primary underline underline-offset-2 text-xs">
                    查看<ChevronRight className="w-3 h-3 inline" />
                  </Link>
                </span>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ────────── 链接归档卡片 ──────────

interface LinkItemCardProps {
  item: LinkItem;
  onSave: () => void;
  onUpdate: (updates: Partial<LinkItem>) => void;
  onRemove: () => void;
}

function LinkItemCard({ item, onSave, onUpdate, onRemove }: LinkItemCardProps) {
  return (
    <Card className={cn('border-border', item.status === 'done' && 'opacity-60')}>
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <Link2 className="w-4 h-4 text-muted-foreground shrink-0" />
            <span className="text-sm text-foreground truncate">{item.name}</span>
            {item.status === 'done' && <CheckCircle className="w-4 h-4 text-[hsl(142_70%_40%)] shrink-0" />}
          </div>
          {item.status !== 'done' && (
            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive" onClick={onRemove}>
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
        <p className="text-xs text-muted-foreground truncate">{item.url}</p>
        {item.status !== 'done' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-xs font-normal text-muted-foreground">名称</Label>
              <Input value={item.name} onChange={(e) => onUpdate({ name: e.target.value })} placeholder="链接名称" className="h-8 text-sm" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs font-normal text-muted-foreground">分类</Label>
              <Select value={item.category} onValueChange={(v) => onUpdate({ category: v })}>
                <SelectTrigger className="h-8 text-sm"><SelectValue placeholder="选择分类" /></SelectTrigger>
                <SelectContent>
                  {ACHIEVEMENT_CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.icon} {c.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-2">
              <Button size="sm" onClick={onSave} disabled={item.status === 'saving'} className="w-full">
                {item.status === 'saving' ? '保存中...' : '保存归档'}
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ────────── 账号密码卡片 ──────────

interface AccountItemCardProps {
  item: AccountItem;
  onSave: () => void;
  onUpdate: (updates: Partial<AccountItem>) => void;
  onRemove: () => void;
}

function AccountItemCard({ item, onSave, onUpdate, onRemove }: AccountItemCardProps) {
  const [showPwd, setShowPwd] = useState(false);
  return (
    <Card className={cn('border-border', item.status === 'done' && 'opacity-60')}>
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm font-medium">{item.platform_name || '新账号'}</span>
            {item.status === 'done' && <CheckCircle className="w-4 h-4 text-[hsl(142_70%_40%)]" />}
          </div>
          {item.status !== 'done' && (
            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive" onClick={onRemove}>
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>

        {item.status !== 'done' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-xs font-normal text-muted-foreground">平台/软件名称 *</Label>
              <Input value={item.platform_name} onChange={(e) => onUpdate({ platform_name: e.target.value })} placeholder="如：学校教务系统" className="h-8 text-sm" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs font-normal text-muted-foreground">账号/用户名 *</Label>
              <Input value={item.username} onChange={(e) => onUpdate({ username: e.target.value })} placeholder="账号" className="h-8 text-sm" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs font-normal text-muted-foreground">密码 *</Label>
              <div className="relative">
                <Input
                  type={showPwd ? 'text' : 'password'}
                  value={item.password}
                  onChange={(e) => onUpdate({ password: e.target.value })}
                  placeholder="密码"
                  className="h-8 text-sm pr-8"
                />
                <button
                  type="button"
                  onClick={() => setShowPwd((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPwd ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-xs font-normal text-muted-foreground">备注（用途/有效期）</Label>
              <Input value={item.notes} onChange={(e) => onUpdate({ notes: e.target.value })} placeholder="如：仅工作日使用" className="h-8 text-sm" />
            </div>
            <div className="md:col-span-2">
              <Button size="sm" onClick={onSave} disabled={item.status === 'saving'} className="w-full">
                <Lock className="w-4 h-4 mr-1.5" />
                {item.status === 'saving' ? '加密保存中...' : '加密保存'}
              </Button>
            </div>
          </div>
        )}

        {item.status === 'done' && (
          <p className="text-xs text-[hsl(142_70%_40%)]">✓ 已加密保存，可在资料管理页的私密账号专区查看</p>
        )}
      </CardContent>
    </Card>
  );
}

