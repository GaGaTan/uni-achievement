import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { ChevronsUpDown, Check } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { EDUCATION_LEVELS, getGradeLabel } from '@/types/types';
import type { Achievement, AccountSecret, RecycleBinItem } from '@/types/types';
import {
  User,
  Bell,
  Shield,
  HardDrive,
  Trash2,
  Lock,
  Eye,
  EyeOff,
  LogOut,
  CheckCircle,
  RotateCcw,
  Settings,
  ChevronRight,
  BookOpen,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { TipBanner } from '@/components/common/HelpTip';

const ENROLLMENT_YEAR_OPTIONS = Array.from({ length: 10 }, (_, i) => ({
  value: String(new Date().getFullYear() - i),
  label: `${new Date().getFullYear() - i} 年`,
}));

const BACKUP_FREQUENCIES = [
  { value: 'daily', label: '每天' },
  { value: 'weekly', label: '每周' },
  { value: 'monthly', label: '每月' },
];

const REMINDER_PERIODS = [
  { value: 'semester_end', label: '学期末' },
  { value: 'award_season', label: '评奖季（每年 9-11 月）' },
  { value: 'job_season', label: '求职季（每年 3-5 月）' },
  { value: 'custom', label: '自定义周期' },
];

const CHINESE_UNIVERSITIES = [
  '清华大学','北京大学','复旦大学','上海交通大学','浙江大学','南京大学','武汉大学',
  '中国人民大学','华中科技大学','中山大学','西安交通大学','哈尔滨工业大学','天津大学',
  '同济大学','北京师范大学','中南大学','东南大学','电子科技大学','北京航空航天大学',
  '厦门大学','吉林大学','山东大学','重庆大学','湖南大学','华南理工大学','中国科学技术大学',
  '北京理工大学','西北工业大学','南开大学','中国农业大学','兰州大学','四川大学',
  '大连理工大学','北京交通大学','华中师范大学','南京航空航天大学','河海大学',
  '苏州大学','湖南师范大学','华东师范大学','南京理工大学','西北大学','暨南大学',
  '北京邮电大学','华中农业大学','南京师范大学','中国海洋大学','北京科技大学',
  '武汉理工大学','东北大学','合肥工业大学','西南大学','郑州大学','云南大学',
  '江南大学','广州大学','深圳大学','北京工业大学','上海大学','首都师范大学',
  '江苏大学','扬州大学','南通大学','徐州工程学院','常州大学','苏州科技大学',
  '江苏理工学院','盐城工学院','淮阴工学院','南京工业大学','无锡太湖学院',
  '成都信息工程大学','西南交通大学','四川师范大学','重庆邮电大学','西南财经大学',
  '广东工业大学','广东外语外贸大学','华南师范大学','深圳技术大学',
  '上海理工大学','上海财经大学','东华大学','上海师范大学',
  '山东农业大学','青岛大学','中国石油大学','中国矿业大学',
  '东北林业大学','哈尔滨工程大学','沈阳工业大学',
  '湖北大学','武汉科技大学','中南财经政法大学','三峡大学',
  '安徽大学','安徽工业大学','安徽财经大学',
  '河南大学','河南工业大学','郑州轻工业大学',
  '西安电子科技大学','长安大学','西北农林科技大学',
  '其他院校',
];

function decryptText(encrypted: string): string {
  try { return atob(encrypted).split('').reverse().join(''); } catch { return '••••••'; }
}

export default function ProfilePage() {
  const { user, profile, refreshProfile, signOut } = useAuth();
  const [activeSection, setActiveSection] = useState<string>('profile');
  const [schoolOpen, setSchoolOpen] = useState(false);
  const [schoolSearch, setSchoolSearch] = useState('');

  // 基础档案
  const [formData, setFormData] = useState({
    name: '', school: '', student_id: '', enrollment_year: '',
    study_years: '', education_level: '',
  });
  const [savingProfile, setSavingProfile] = useState(false);

  // 系统设置
  const [soundReminder, setSoundReminder] = useState(false);
  const [backupEnabled, setBackupEnabled] = useState(false);
  const [backupFrequency, setBackupFrequency] = useState('weekly');
  const [reminderEnabled, setReminderEnabled] = useState(false);
  const [reminderScenes, setReminderScenes] = useState<string[]>(['semester_end']);
  const [appLockEnabled, setAppLockEnabled] = useState(false);

  // 修改密码
  const [pwdDialogOpen, setPwdDialogOpen] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [showPin, setShowPin] = useState(false);

  // 回收站
  const [recycleBin, setRecycleBin] = useState<RecycleBinItem[]>([]);
  const [recycleBinLoading, setRecycleBinLoading] = useState(false);
  const [restoring, setRestoring] = useState<string | null>(null);
  const [clearBinConfirm, setClearBinConfirm] = useState(false);

  // 账号注销
  const [deleteAccountConfirm, setDeleteAccountConfirm] = useState(false);

  useEffect(() => {
    if (profile) {
      setFormData({
        name: profile.name || '',
        school: profile.school || '',
        student_id: profile.student_id || '',
        enrollment_year: profile.enrollment_year ? String(profile.enrollment_year) : '',
        study_years: profile.study_years ? String(profile.study_years) : '',
        education_level: profile.education_level || '',
      });
      setSoundReminder(profile.sound_reminder ?? false);
      setBackupEnabled(profile.backup_enabled ?? false);
      setBackupFrequency(profile.backup_frequency || 'weekly');
      setReminderEnabled(profile.reminder_enabled ?? false);
      setReminderScenes(profile.reminder_scenes || ['semester_end']);
      setAppLockEnabled(profile.app_lock_enabled ?? false);
    }
  }, [profile]);

  const saveProfile = async () => {
    if (!user) return;
    setSavingProfile(true);
    try {
      const { error } = await supabase.from('profiles').update({
        name: formData.name || null,
        school: formData.school || null,
        student_id: formData.student_id || null,
        enrollment_year: formData.enrollment_year ? parseInt(formData.enrollment_year) : null,
        
        education_level: formData.education_level || null,
      }).eq('id', user.id);
      if (error) throw error;
      await refreshProfile();
      toast.success('个人档案已保存');
    } catch (err) {
      toast.error('保存失败：' + (err instanceof Error ? err.message : '未知错误'));
    }
    setSavingProfile(false);
  };

  const saveSettings = async (overrides: Record<string, unknown> = {}) => {
    if (!user) return;
    try {
      const updates = {
        sound_reminder: soundReminder,
        backup_enabled: backupEnabled,
        backup_frequency: backupFrequency,
        reminder_enabled: reminderEnabled,
        reminder_scenes: reminderScenes,
        app_lock_enabled: appLockEnabled,
        ...overrides,
      };
      const { error } = await supabase.from('profiles').update(updates).eq('id', user.id);
      if (error) throw error;
      await refreshProfile();
      toast.success('设置已保存');
    } catch (err) {
      toast.error('保存失败');
    }
  };

  const fetchRecycleBin = async () => {
    if (!user) return;
    setRecycleBinLoading(true);
    const { data } = await supabase.from('recycle_bin').select('*').eq('user_id', user.id).order('deleted_at', { ascending: false }).limit(50);
    setRecycleBin(Array.isArray(data) ? data : []);
    setRecycleBinLoading(false);
  };

  useEffect(() => {
    if (activeSection === 'recycle') fetchRecycleBin();
  }, [activeSection]);

  const restoreItem = async (item: RecycleBinItem) => {
    setRestoring(item.id);
    try {
      if (item.item_type === 'achievement') {
        const { id: _id, ...restData } = item.item_data as Achievement;
        void _id;
        await supabase.from('achievements').insert(restData);
      }
      await supabase.from('recycle_bin').delete().eq('id', item.id);
      setRecycleBin((prev) => prev.filter((r) => r.id !== item.id));
      toast.success('材料已恢复');
    } catch (err) {
      toast.error('恢复失败');
    }
    setRestoring(null);
  };

  const permanentDelete = async (item: RecycleBinItem) => {
    await supabase.from('recycle_bin').delete().eq('id', item.id);
    setRecycleBin((prev) => prev.filter((r) => r.id !== item.id));
    toast.success('已永久删除');
  };

  const clearRecycleBin = async () => {
    await supabase.from('recycle_bin').delete().eq('user_id', user!.id);
    setRecycleBin([]);
    setClearBinConfirm(false);
    toast.success('回收站已清空');
  };

  const currentGradeYear = profile?.enrollment_year
    ? new Date().getFullYear() - profile.enrollment_year + (new Date().getMonth() >= 8 ? 1 : 0)
    : null;

  const MENU_ITEMS = [
    { key: 'profile', label: '个人档案', icon: User },
    { key: 'sound', label: '铃声提醒', icon: Bell },
    { key: 'privacy', label: '隐私安全', icon: Shield },
    { key: 'backup', label: '备份设置', icon: HardDrive },
    { key: 'reminder', label: '归档提醒', icon: Bell },
    { key: 'recycle', label: '回收站', icon: Trash2 },
    { key: 'account', label: '账号管理', icon: Settings },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-foreground text-balance">个人中心</h1>
        <p className="text-sm text-muted-foreground mt-1">
          {user?.email || user?.phone || '未登录'}
        </p>
      </div>

      <TipBanner>
        <strong>个人中心说明：</strong>在「基本信息」完善姓名、学校、专业等信息，系统将用于生成精准的导出材料。「安全设置」可修改密码。信息完善越充分，AI归档和导出效果越好。
      </TipBanner>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* 左侧菜单 */}
        <nav className="md:col-span-1 space-y-1">
          {MENU_ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                onClick={() => setActiveSection(item.key)}
                className={cn(
                  'w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm transition-colors text-left',
                  activeSection === item.key
                    ? 'bg-primary text-primary-foreground font-medium'
                    : 'text-foreground hover:bg-muted'
                )}
              >
                <Icon className="w-4 h-4 shrink-0" />
                {item.label}
                <ChevronRight className={cn('w-3.5 h-3.5 ml-auto', activeSection === item.key ? 'text-primary-foreground/60' : 'text-muted-foreground')} />
              </button>
            );
          })}
        </nav>

        {/* 右侧内容 */}
        <div className="md:col-span-3 space-y-4">
          {/* ── 个人档案 ── */}
          {activeSection === 'profile' && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">基础档案信息</CardTitle>
                <CardDescription className="text-xs">系统根据以下信息自动匹配年级，作为材料分类基础</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label className="text-xs font-normal text-muted-foreground">姓名</Label>
                    <Input value={formData.name} onChange={(e) => setFormData((f) => ({ ...f, name: e.target.value }))} placeholder="请输入真实姓名" className="text-sm" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-normal text-muted-foreground">学校</Label>
                    <Popover open={schoolOpen} onOpenChange={setSchoolOpen}>
                      <PopoverTrigger asChild>
                        <Button variant="outline" role="combobox" aria-expanded={schoolOpen} className="w-full justify-between text-sm font-normal h-9 px-3">
                          <span className="truncate">{formData.school || '搜索并选择院校'}</span>
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-full p-0" align="start">
                        <Command>
                          <CommandInput placeholder="搜索院校名称..." value={schoolSearch} onValueChange={setSchoolSearch} />
                          <CommandList>
                            <CommandEmpty>未找到匹配院校，可直接输入</CommandEmpty>
                            <CommandGroup>
                              {CHINESE_UNIVERSITIES.filter((s) => schoolSearch ? s.includes(schoolSearch) : true).map((school) => (
                                <CommandItem key={school} value={school} onSelect={(v) => { setFormData((f) => ({ ...f, school: v })); setSchoolOpen(false); setSchoolSearch(''); }}>
                                  <Check className={cn("mr-2 h-4 w-4", formData.school === school ? "opacity-100" : "opacity-0")} />
                                  {school}
                                </CommandItem>
                              ))}
                              {schoolSearch && !CHINESE_UNIVERSITIES.includes(schoolSearch) && (
                                <CommandItem value={schoolSearch} onSelect={() => { setFormData((f) => ({ ...f, school: schoolSearch })); setSchoolOpen(false); setSchoolSearch(''); }}>
                                  <Check className="mr-2 h-4 w-4 opacity-0" />
                                  使用 "{schoolSearch}"
                                </CommandItem>
                              )}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-normal text-muted-foreground">学号</Label>
                    <Input value={formData.student_id} onChange={(e) => setFormData((f) => ({ ...f, student_id: e.target.value }))} placeholder="学号" className="text-sm" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-normal text-muted-foreground">入学年份</Label>
                    <Select value={formData.enrollment_year} onValueChange={(v) => setFormData((f) => ({ ...f, enrollment_year: v }))}>
                      <SelectTrigger className="text-sm"><SelectValue placeholder="选择入学年份" /></SelectTrigger>
                      <SelectContent>
                        {ENROLLMENT_YEAR_OPTIONS.map((y) => <SelectItem key={y.value} value={y.value}>{y.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-normal text-muted-foreground">学历层次</Label>
                    <Select value={formData.education_level} onValueChange={(v) => setFormData((f) => ({ ...f, education_level: v }))}>
                      <SelectTrigger className="text-sm"><SelectValue placeholder="选择学历层次" /></SelectTrigger>
                      <SelectContent>
                        {EDUCATION_LEVELS.map((l) => <SelectItem key={l.value} value={l.value}>{l.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-normal text-muted-foreground">学制（年）</Label>
                    <Select value={formData.study_years} onValueChange={(v) => setFormData((f) => ({ ...f, study_years: v }))}>
                      <SelectTrigger className="text-sm"><SelectValue placeholder="选择学制" /></SelectTrigger>
                      <SelectContent>
                        {['2', '3', '4', '5'].map((v) => <SelectItem key={v} value={v}>{v} 年制</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {formData.enrollment_year && formData.education_level && currentGradeYear && (
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50 text-sm">
                    <BookOpen className="w-4 h-4 text-primary shrink-0" />
                    <span>当前年级：<strong>{getGradeLabel(currentGradeYear, formData.education_level)}</strong></span>
                  </div>
                )}

                <Button onClick={saveProfile} disabled={savingProfile} className="w-full md:w-auto">
                  {savingProfile ? '保存中...' : '保存档案'}
                </Button>
              </CardContent>
            </Card>
          )}

          {/* ── 铃声提醒 ── */}
          {activeSection === 'sound' && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">铃声提醒设置</CardTitle>
                <CardDescription className="text-xs">归档成功时触发提示铃声</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">归档成功提示音</p>
                    <p className="text-xs text-muted-foreground mt-0.5">每次成功归档材料时播放提示音</p>
                  </div>
                  <Switch
                    checked={soundReminder}
                    onCheckedChange={(v) => { setSoundReminder(v); saveSettings({ sound_reminder: v }); }}
                  />
                </div>

                {soundReminder && (
                  <>
                    <Separator />
                    <div className="space-y-2">
                      <p className="text-xs text-muted-foreground">铃声预览</p>
                      <div className="flex gap-2">
                        {['清脆叮咚', '轻柔提示', '双音节铃声'].map((name) => (
                          <Button key={name} size="sm" variant="outline" className="text-xs" onClick={() => {}}>{name}</Button>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          )}

          {/* ── 隐私安全 ── */}
          {activeSection === 'privacy' && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">隐私与安全</CardTitle>
                <CardDescription className="text-xs">保护您的账号和敏感材料安全</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">APP锁定</p>
                    <p className="text-xs text-muted-foreground mt-0.5">启动应用时需要验证密码才能使用</p>
                  </div>
                  <Switch
                    checked={appLockEnabled}
                    onCheckedChange={(v) => { setAppLockEnabled(v); saveSettings({ app_lock_enabled: v }); }}
                  />
                </div>

                {appLockEnabled && (
                  <>
                    <Button variant="outline" size="sm" className="w-full" onClick={() => setPwdDialogOpen(true)}>
                      <Lock className="w-4 h-4 mr-1.5" />
                      修改锁定密码
                    </Button>
                  </>
                )}

                <Separator />

                <div>
                  <p className="text-sm font-medium mb-1">私密材料保护</p>
                  <p className="text-xs text-muted-foreground">
                    标记为私密的材料需要二级验证才可查看。账号密码信息经客户端加密存储，服务器无法读取。
                  </p>
                </div>

                <Separator />

                <div className="space-y-2">
                  <p className="text-sm font-medium">账号安全</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-muted-foreground">
                    <div className="p-2 rounded bg-muted/50">
                      <p className="font-medium text-foreground">登录邮箱/手机</p>
                      <p>{user?.email || user?.phone || '未设置'}</p>
                    </div>
                    <div className="p-2 rounded bg-muted/50">
                      <p className="font-medium text-foreground">注册时间</p>
                      <p>{user?.created_at ? new Date(user.created_at).toLocaleDateString() : '-'}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* ── 备份设置 ── */}
          {activeSection === 'backup' && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">备份与存储</CardTitle>
                <CardDescription className="text-xs">保障所有材料安全留存，防止丢失</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">自动云端备份</p>
                    <p className="text-xs text-muted-foreground mt-0.5">自动将材料备份至安全云端存储</p>
                  </div>
                  <Switch
                    checked={backupEnabled}
                    onCheckedChange={(v) => { setBackupEnabled(v); saveSettings({ backup_enabled: v }); }}
                  />
                </div>

                {backupEnabled && (
                  <>
                    <div className="space-y-2">
                      <Label className="text-xs font-normal text-muted-foreground">备份频率</Label>
                      <Select value={backupFrequency} onValueChange={(v) => { setBackupFrequency(v); saveSettings({ backup_frequency: v }); }}>
                        <SelectTrigger className="text-sm"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {BACKUP_FREQUENCIES.map((f) => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[hsl(142_70%_40%)] shrink-0" />
                      所有材料已加密备份至云端，私密账号密码全程高强度加密传输
                    </div>
                  </>
                )}

                <Separator />

                <div>
                  <p className="text-sm font-medium mb-2">全量导出备份</p>
                  <p className="text-xs text-muted-foreground mb-3">一键导出所有成就、证件、实习、任职材料，生成离线归档包</p>
                  <Button variant="outline" size="sm" className="w-full md:w-auto" onClick={() => toast.info('请前往"导出与分享"页面使用全量导出功能')}>
                    <HardDrive className="w-4 h-4 mr-1.5" />
                    前往全量导出
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* ── 归档提醒 ── */}
          {activeSection === 'reminder' && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">归档提醒设置</CardTitle>
                <CardDescription className="text-xs">定期提醒补录成就材料，避免遗漏</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">开启归档提醒</p>
                    <p className="text-xs text-muted-foreground mt-0.5">自动推送提醒，避免材料遗漏</p>
                  </div>
                  <Switch
                    checked={reminderEnabled}
                    onCheckedChange={(v) => { setReminderEnabled(v); saveSettings({ reminder_enabled: v }); }}
                  />
                </div>

                {reminderEnabled && (
                  <>
                    <Separator />
                    <div className="space-y-3">
                      <p className="text-sm font-medium">提醒场景</p>
                      {REMINDER_PERIODS.map((rp) => (
                        <div key={rp.value} className="flex items-center justify-between">
                          <p className="text-sm">{rp.label}</p>
                          <Switch
                            checked={reminderScenes.includes(rp.value)}
                            onCheckedChange={(v) => {
                              const next = v ? [...reminderScenes, rp.value] : reminderScenes.filter((s) => s !== rp.value);
                              setReminderScenes(next);
                              saveSettings({ reminder_scenes: next });
                            }}
                          />
                        </div>
                      ))}
                    </div>

                    <div className="p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground">
                      系统将在对应时期自动发送提醒，点击提醒可直接跳转至上传归档入口
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          )}

          {/* ── 回收站 ── */}
          {activeSection === 'recycle' && (
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-base">回收站</CardTitle>
                    <CardDescription className="text-xs mt-0.5">30天内误删的材料可在此恢复</CardDescription>
                  </div>
                  {recycleBin.length > 0 && (
                    <Button variant="outline" size="sm" className="shrink-0" onClick={() => setClearBinConfirm(true)}>
                      <Trash2 className="w-3 h-3 mr-1" />清空
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {recycleBinLoading ? (
                  <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-14 bg-muted rounded animate-pulse" />)}</div>
                ) : recycleBin.length === 0 ? (
                  <div className="text-center py-10 text-muted-foreground">
                    <Trash2 className="w-12 h-12 mx-auto mb-3 opacity-20" />
                    <p className="text-sm">回收站为空</p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {recycleBin.map((item) => {
                      const data = item.item_data as Achievement;
                      const daysLeft = item.expires_at
                        ? Math.max(0, Math.ceil((new Date(item.expires_at).getTime() - Date.now()) / 86400000))
                        : 30;
                      return (
                        <div key={item.id} className="flex items-center gap-3 p-3 rounded-lg border border-border">
                          <div className="w-10 h-10 rounded overflow-hidden bg-muted shrink-0">
                            {data?.image_url ? (
                              <img src={data.image_url} alt={data.name} className="w-full h-full object-cover" />
                            ) : <Trash2 className="w-4 h-4 m-3 text-muted-foreground" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm truncate">{data?.name || '未知材料'}</p>
                            <p className="text-xs text-muted-foreground">
                              {daysLeft > 0 ? `${daysLeft}天后自动删除` : '即将自动删除'}
                            </p>
                          </div>
                          <div className="flex gap-1 shrink-0">
                            <Button
                              size="sm" variant="outline" className="h-7 text-xs px-2"
                              disabled={restoring === item.id}
                              onClick={() => restoreItem(item)}
                            >
                              <RotateCcw className="w-3 h-3 mr-1" />{restoring === item.id ? '恢复中' : '恢复'}
                            </Button>
                            <Button
                              size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive"
                              onClick={() => permanentDelete(item)}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* ── 账号管理 ── */}
          {activeSection === 'account' && (
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">账号信息</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-1 gap-3 text-sm">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span className="text-muted-foreground">账号类型</span>
                      <span>{user?.app_metadata?.provider === 'phone' ? '手机号登录' : '邮箱登录'}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span className="text-muted-foreground">{user?.email ? '邮箱' : '手机号'}</span>
                      <span className="font-mono text-xs">{user?.email || user?.phone || '-'}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span className="text-muted-foreground">注册时间</span>
                      <span>{user?.created_at ? new Date(user.created_at).toLocaleDateString() : '-'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base text-destructive">危险操作</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg border border-destructive/30 bg-destructive/5">
                    <p className="text-sm font-medium text-destructive mb-1">注销账号</p>
                    <p className="text-xs text-muted-foreground mb-3">注销后将自动清除所有个人资料、私密账号密码及归档材料，不可恢复。</p>
                    <Button variant="destructive" size="sm" onClick={() => setDeleteAccountConfirm(true)}>
                      注销账号
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Button variant="outline" className="w-full" onClick={signOut}>
                <LogOut className="w-4 h-4 mr-1.5" />
                退出登录
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* 修改锁定密码弹窗 */}
      <Dialog open={pwdDialogOpen} onOpenChange={setPwdDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle>设置应用锁定密码</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1">
              <Label className="text-xs font-normal text-muted-foreground">新密码（6-16位）</Label>
              <div className="relative">
                <Input
                  type={showPin ? 'text' : 'password'}
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value)}
                  placeholder="请设置锁定密码"
                  className="pr-8"
                />
                <button type="button" onClick={() => setShowPin((v) => !v)} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground">
                  {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setPwdDialogOpen(false)}>取消</Button>
              <Button onClick={async () => {
                if (!newPin || newPin.length < 6) { toast.error('密码至少6位'); return; }
                await saveSettings({ app_lock_pin: newPin });
                setPwdDialogOpen(false);
                setNewPin('');
                toast.success('锁定密码已更新');
              }}>确认设置</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* 清空回收站确认 */}
      <AlertDialog open={clearBinConfirm} onOpenChange={setClearBinConfirm}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>清空回收站</AlertDialogTitle>
            <AlertDialogDescription>确定要永久清空回收站中所有 {recycleBin.length} 条材料吗？此操作不可撤销。</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={clearRecycleBin} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">确认清空</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 注销账号确认 */}
      <AlertDialog open={deleteAccountConfirm} onOpenChange={setDeleteAccountConfirm}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>注销账号</AlertDialogTitle>
            <AlertDialogDescription>此操作将永久删除您的所有数据，包括成就材料、证件照、私密账号密码等，无法恢复。确认注销吗？</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={async () => {
              try {
                await supabase.from('achievements').delete().eq('user_id', user!.id);
                await supabase.from('account_secrets').delete().eq('user_id', user!.id);
                await supabase.from('recycle_bin').delete().eq('user_id', user!.id);
                await supabase.from('share_links').delete().eq('user_id', user!.id);
                await signOut();
                toast.success('账号已注销');
              } catch { toast.error('注销失败，请联系客服'); }
              setDeleteAccountConfirm(false);
            }}>确认注销</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
