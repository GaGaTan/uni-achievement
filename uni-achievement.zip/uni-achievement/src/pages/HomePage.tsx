import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
} from '@/components/ui/dialog';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import {
  ACHIEVEMENT_CATEGORIES,
  ACHIEVEMENT_LEVELS,
  getGradeLabel,
} from '@/types/types';
import type { Achievement, AccountSecret } from '@/types/types';
import {
  Upload,
  X,
  Trash2,
  Calendar,
  Tag,
  Award,
  ZoomIn,
  FileDown,
  GraduationCap,
  Search,
  CheckSquare,
  Square,
  FolderOpen,
  BarChart2,
  Clock,
  Lock,
  Eye,
  EyeOff,
  FileText,
  Link2,
  Image as ImageIcon,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { HelpTip, TipBanner } from '@/components/common/HelpTip';

// 年级选项
const GRADE_OPTIONS = [
  { value: '1', label: '大一/研一/博一' },
  { value: '2', label: '大二/研二/博二' },
  { value: '3', label: '大三/研三/博三' },
  { value: '4', label: '大四/博四' },
  { value: '5', label: '大五' },
];

const currentYear = new Date().getFullYear();
const YEAR_OPTIONS = Array.from({ length: 6 }, (_, i) => ({
  value: String(currentYear - i),
  label: `${currentYear - i} 年`,
}));

const CATEGORY_COLORS: Record<string, string> = {
  '荣誉奖项': 'bg-[hsl(35_90%_55%/0.12)] text-[hsl(35_80%_35%)] border-[hsl(35_90%_55%/0.3)]',
  '赛事竞赛': 'bg-[hsl(200_80%_45%/0.12)] text-[hsl(200_70%_35%)] border-[hsl(200_80%_45%/0.3)]',
  '志愿实践': 'bg-[hsl(142_70%_40%/0.12)] text-[hsl(142_60%_30%)] border-[hsl(142_70%_40%/0.3)]',
  '学术成果': 'bg-[hsl(280_50%_55%/0.12)] text-[hsl(280_40%_35%)] border-[hsl(280_50%_55%/0.3)]',
  '学生工作': 'bg-[hsl(180_38%_15%/0.08)] text-[hsl(180_38%_25%)] border-[hsl(180_38%_15%/0.2)]',
  '个人证件': 'bg-[hsl(15_80%_50%/0.12)] text-[hsl(15_70%_35%)] border-[hsl(15_80%_50%/0.3)]',
  '其他': 'bg-muted text-muted-foreground border-border',
};

const CHART_COLORS = ['#1A3636', '#F5A623', '#2D9CDB', '#9B59B6', '#27AE60', '#E74C3C', '#F39C12', '#1ABC9C'];

function decryptText(encrypted: string): string {
  try { return atob(encrypted).split('').reverse().join(''); } catch { return '••••••'; }
}

function getFileIcon(fileType: string) {
  if (fileType === 'pdf') return <FileText className="w-5 h-5 text-red-500" />;
  if (fileType === 'word') return <FileText className="w-5 h-5 text-blue-500" />;
  if (fileType === 'excel') return <FileText className="w-5 h-5 text-green-600" />;
  if (fileType === 'link') return <Link2 className="w-5 h-5 text-primary" />;
  return <ImageIcon className="w-5 h-5 text-muted-foreground" />;
}

export default function HomePage() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  // 筛选
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterLevel, setFilterLevel] = useState<string>('all');
  const [filterGradeYear, setFilterGradeYear] = useState<string>('all');
  const [filterYear, setFilterYear] = useState<string>('all');
  const [searchKeyword, setSearchKeyword] = useState('');

  // 批量操作
  const [batchMode, setBatchMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // 详情侧边栏
  const [selectedAchievement, setSelectedAchievement] = useState<Achievement | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  // 全屏图片预览
  const [previewImageUrl, setPreviewImageUrl] = useState<string | null>(null);

  // 删除确认
  const [deleteTarget, setDeleteTarget] = useState<Achievement | null>(null);
  const [batchDeleteConfirm, setBatchDeleteConfirm] = useState(false);

  // 私密账号
  const [accountSecrets, setAccountSecrets] = useState<AccountSecret[]>([]);
  const [accountsLoading, setAccountsLoading] = useState(false);
  const [accountsUnlocked, setAccountsUnlocked] = useState(false);
  const [revealedIds, setRevealedIds] = useState<Set<string>>(new Set());

  const fetchAchievements = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    let query = supabase
      .from('achievements')
      .select('*')
      .eq('user_id', user.id)
      .order('achieved_at', { ascending: false, nullsFirst: false })
      .order('created_at', { ascending: false });

    if (filterCategory !== 'all') query = query.eq('category', filterCategory);
    if (filterLevel !== 'all') query = query.eq('level', filterLevel);
    if (filterGradeYear !== 'all') query = query.eq('grade_year', parseInt(filterGradeYear));
    if (filterYear !== 'all') query = query.gte('achieved_at', `${filterYear}-01-01`).lte('achieved_at', `${filterYear}-12-31`);

    const { data, error } = await query;
    if (error) toast.error('加载失败：' + error.message);
    else setAchievements(Array.isArray(data) ? data : []);
    setLoading(false);
  }, [user, filterCategory, filterLevel, filterGradeYear, filterYear]);

  useEffect(() => { fetchAchievements(); }, [fetchAchievements]);

  const fetchAccountSecrets = async () => {
    if (!user) return;
    setAccountsLoading(true);
    const { data, error } = await supabase.from('account_secrets').select('*').eq('user_id', user.id).order('sort_order').order('created_at', { ascending: false });
    if (!error) setAccountSecrets(Array.isArray(data) ? data : []);
    setAccountsLoading(false);
  };

  const handleUnlockAccounts = () => {
    const pin = window.prompt('请输入访问密码（默认为账号登录密码前6位）：');
    if (pin !== null) {
      setAccountsUnlocked(true);
      fetchAccountSecrets();
    }
  };

  const hasFilters = filterCategory !== 'all' || filterLevel !== 'all' || filterGradeYear !== 'all' || filterYear !== 'all' || searchKeyword !== '';

  const clearFilters = () => {
    setFilterCategory('all'); setFilterLevel('all');
    setFilterGradeYear('all'); setFilterYear('all');
    setSearchKeyword('');
  };

  // 关键词过滤
  const filteredAchievements = achievements.filter((a) => {
    if (!searchKeyword) return true;
    const kw = searchKeyword.toLowerCase();
    return (
      a.name.toLowerCase().includes(kw) ||
      (a.category?.toLowerCase().includes(kw)) ||
      (a.subcategory?.toLowerCase().includes(kw)) ||
      (a.notes?.toLowerCase().includes(kw)) ||
      (a.ai_description?.toLowerCase().includes(kw)) ||
      (a.tags?.some((t) => t.toLowerCase().includes(kw)))
    );
  });

  const handleDelete = async (achievement: Achievement) => {
    try {
      // 移入回收站
      await supabase.from('recycle_bin').insert({
        user_id: user!.id,
        item_type: 'achievement',
        original_id: achievement.id,
        item_data: achievement,
      });
      if (achievement.image_path) await supabase.storage.from('achievements').remove([achievement.image_path]);
      const { error } = await supabase.from('achievements').delete().eq('id', achievement.id);
      if (error) throw error;
      toast.success('已移入回收站（30天内可恢复）');
      setDetailOpen(false);
      fetchAchievements();
    } catch (err) {
      toast.error('删除失败：' + (err instanceof Error ? err.message : '未知错误'));
    }
    setDeleteTarget(null);
  };

  const handleBatchDelete = async () => {
    const targets = achievements.filter((a) => selectedIds.has(a.id));
    for (const a of targets) { await handleDelete(a); }
    setSelectedIds(new Set());
    setBatchMode(false);
    setBatchDeleteConfirm(false);
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const selectAll = () => setSelectedIds(new Set(filteredAchievements.map((a) => a.id)));
  const clearSelection = () => setSelectedIds(new Set());

  const getCategoryInfo = (category: string) => ACHIEVEMENT_CATEGORIES.find((c) => c.value === category);

  // 证件照专区
  const certAchievements = achievements.filter((a) => a.category === '个人证件');

  // 时间轴分组（按年级）
  const timelineGroups = (() => {
    const groups: Record<number, Achievement[]> = {};
    achievements.forEach((a) => {
      const key = a.grade_year ?? 0;
      if (!groups[key]) groups[key] = [];
      groups[key].push(a);
    });
    return Object.entries(groups)
      .sort(([a], [b]) => Number(b) - Number(a))
      .map(([grade, items]) => ({ grade: Number(grade), items }));
  })();

  // 统计数据
  const statsData = (() => {
    const catCounts: Record<string, number> = {};
    const levelCounts: Record<string, number> = {};
    const yearCounts: Record<string, number> = {};
    let totalVolunteerHours = 0;
    achievements.forEach((a) => {
      catCounts[a.category] = (catCounts[a.category] || 0) + 1;
      if (a.level) levelCounts[a.level] = (levelCounts[a.level] || 0) + 1;
      if (a.achieved_at) {
        const y = a.achieved_at.slice(0, 4);
        yearCounts[y] = (yearCounts[y] || 0) + 1;
      }
      if (a.volunteer_hours) totalVolunteerHours += a.volunteer_hours;
    });
    return {
      catPie: Object.entries(catCounts).map(([name, value]) => ({ name, value })),
      levelBar: Object.entries(levelCounts).map(([name, value]) => ({ name, value })),
      yearBar: Object.entries(yearCounts).sort(([a], [b]) => a.localeCompare(b)).map(([name, value]) => ({ name, value })),
      totalVolunteerHours,
      total: achievements.length,
      internshipCount: achievements.filter((a) => a.subcategory === '实习经历' || a.category === '志愿实践').length,
      workCount: achievements.filter((a) => a.category === '学生工作').length,
    };
  })();

  return (
    <div className="space-y-5">
      {/* 标题 */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-foreground text-balance">资料管理</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            共 {achievements.length} 条材料
            {profile?.name && `，${profile.name}`}
            {profile?.enrollment_year && profile.education_level && (
              <span className="ml-1">
                （{getGradeLabel(
                  new Date().getFullYear() - profile.enrollment_year + (new Date().getMonth() >= 8 ? 1 : 0),
                  profile.education_level
                )}）
              </span>
            )}
          </p>
        </div>
        <Button size="sm" onClick={() => navigate('/upload')}>
          <Upload className="w-4 h-4 mr-1.5" />
          上传材料
        </Button>
      </div>

      <TipBanner>
        <strong>系统导航：</strong>
        「全部资料」查看并管理所有归档材料；
        「时间轴」按时间展示成长历程；
        「数据统计」可视化分析成就分布；
        「证件专区」管理证件照；
        「私密账号」查看已存储的账号密码。
        如需上传新材料，点击右上角「上传材料」按钮。
      </TipBanner>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-2 flex-wrap h-auto gap-1">
          <TabsTrigger value="all" className="text-xs"><FolderOpen className="w-3.5 h-3.5 mr-1" />全部资料</TabsTrigger>
          <TabsTrigger value="timeline" className="text-xs"><Clock className="w-3.5 h-3.5 mr-1" />成长时间轴</TabsTrigger>
          <TabsTrigger value="stats" className="text-xs"><BarChart2 className="w-3.5 h-3.5 mr-1" />数据统计</TabsTrigger>
          <TabsTrigger value="cert" className="text-xs"><Award className="w-3.5 h-3.5 mr-1" />证件专区</TabsTrigger>
          <TabsTrigger value="accounts" className="text-xs"><Lock className="w-3.5 h-3.5 mr-1" />私密账号</TabsTrigger>
        </TabsList>

        {/* ── 全部资料 ── */}
        <TabsContent value="all" className="space-y-4">
          {/* 搜索 + 筛选 */}
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                placeholder="搜索材料名称、分类、备注..."
                className="pl-9 text-sm"
              />
              {searchKeyword && (
                <button onClick={() => setSearchKeyword('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="全部分类" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部分类</SelectItem>
                {ACHIEVEMENT_CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.icon} {c.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filterLevel} onValueChange={setFilterLevel}>
              <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="全部等级" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部等级</SelectItem>
                {ACHIEVEMENT_LEVELS.map((l) => <SelectItem key={l.value} value={l.value}>{l.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filterGradeYear} onValueChange={setFilterGradeYear}>
              <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="全部年级" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部年级</SelectItem>
                {GRADE_OPTIONS.map((g) => <SelectItem key={g.value} value={g.value}>{g.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filterYear} onValueChange={setFilterYear}>
              <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="全部年份" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部年份</SelectItem>
                {YEAR_OPTIONS.map((y) => <SelectItem key={y.value} value={y.value}>{y.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {/* 批量操作栏 */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              {hasFilters && (
                <Button variant="outline" size="sm" className="h-7 text-xs" onClick={clearFilters}>
                  <X className="w-3 h-3 mr-1" />清除筛选
                </Button>
              )}
              <span className="text-xs text-muted-foreground">
                {filteredAchievements.length} 条结果
              </span>
            </div>
            <div className="flex gap-2">
              {batchMode ? (
                <>
                  <Button size="sm" variant="outline" className="h-7 text-xs" onClick={selectedIds.size === filteredAchievements.length ? clearSelection : selectAll}>
                    {selectedIds.size === filteredAchievements.length ? '取消全选' : '全选'}
                  </Button>
                  {selectedIds.size > 0 && (
                    <>
                      <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => navigate(`/export?ids=${[...selectedIds].join(',')}`)}>
                        <FileDown className="w-3 h-3 mr-1" />导出({selectedIds.size})
                      </Button>
                      <Button size="sm" variant="destructive" className="h-7 text-xs" onClick={() => setBatchDeleteConfirm(true)}>
                        <Trash2 className="w-3 h-3 mr-1" />删除({selectedIds.size})
                      </Button>
                    </>
                  )}
                  <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => { setBatchMode(false); clearSelection(); }}>
                    退出
                  </Button>
                </>
              ) : (
                <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setBatchMode(true)}>
                  <CheckSquare className="w-3 h-3 mr-1" />批量操作
                </Button>
              )}
            </div>
          </div>

          {/* 材料卡片网格 */}
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-48 rounded-lg bg-muted" />)}
            </div>
          ) : filteredAchievements.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <FolderOpen className="w-14 h-14 mx-auto mb-3 opacity-20" />
              <p className="text-sm font-medium">{hasFilters ? '没有符合筛选条件的材料' : '暂无成就材料'}</p>
              <p className="text-xs mt-1">{hasFilters ? '尝试调整筛选条件' : '点击"上传材料"开始归档'}</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {filteredAchievements.map((achievement) => (
                <AchievementCard
                  key={achievement.id}
                  achievement={achievement}
                  batchMode={batchMode}
                  selected={selectedIds.has(achievement.id)}
                  onSelect={() => toggleSelect(achievement.id)}
                  onClick={() => { setSelectedAchievement(achievement); setDetailOpen(true); }}
                  onPreview={(url) => setPreviewImageUrl(url)}
                />
              ))}
            </div>
          )}
        </TabsContent>

        {/* ── 成长时间轴 ── */}
        <TabsContent value="timeline" className="space-y-2">
          {loading ? (
            <div className="space-y-4">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-32 bg-muted" />)}</div>
          ) : timelineGroups.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <Clock className="w-14 h-14 mx-auto mb-3 opacity-20" />
              <p className="text-sm">暂无时间轴数据，上传材料后自动生成</p>
            </div>
          ) : (
            <div className="space-y-6">
              {timelineGroups.map(({ grade, items }) => (
                <div key={grade} className="relative">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shrink-0">
                      <GraduationCap className="w-4 h-4 text-primary-foreground" />
                    </div>
                    <h3 className="font-semibold text-sm text-foreground">
                      {grade === 0 ? '未分年级' : profile?.education_level
                        ? getGradeLabel(grade, profile.education_level)
                        : `第${grade}年`}
                      <span className="ml-2 text-xs font-normal text-muted-foreground">{items.length} 条</span>
                    </h3>
                  </div>
                  <div className="ml-4 pl-6 border-l-2 border-border space-y-2">
                    {items.map((a) => (
                      <div
                        key={a.id}
                        className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card hover:bg-muted/30 cursor-pointer transition-colors"
                        onClick={() => { setSelectedAchievement(a); setDetailOpen(true); }}
                      >
                        <div className="w-10 h-10 rounded overflow-hidden shrink-0 bg-muted flex items-center justify-center">
                          {a.file_type === 'image' && a.image_url ? (
                            <img src={a.image_url} alt={a.name} className="w-full h-full object-cover" />
                          ) : getFileIcon(a.file_type || 'image')}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{a.name}</p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-xs text-muted-foreground">{a.category}</span>
                            {a.achieved_at && <span className="text-xs text-muted-foreground">{a.achieved_at}</span>}
                            {a.level && <Badge variant="outline" className="text-xs py-0 h-4">{a.level}</Badge>}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ── 数据统计 ── */}
        <TabsContent value="stats" className="space-y-4">
          {/* 汇总卡片 */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: '总材料数', value: statsData.total, icon: '📁' },
              { label: '志愿总时长', value: `${statsData.totalVolunteerHours}h`, icon: '🤝' },
              { label: '实习/实践', value: statsData.internshipCount, icon: '💼' },
              { label: '学生工作', value: statsData.workCount, icon: '🏫' },
            ].map((item) => (
              <Card key={item.label} className="h-full">
                <CardContent className="p-4 flex flex-col items-center text-center">
                  <span className="text-2xl mb-1">{item.icon}</span>
                  <span className="text-2xl font-bold text-foreground">{item.value}</span>
                  <span className="text-xs text-muted-foreground mt-0.5">{item.label}</span>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* 分类分布饼图 */}
            <Card className="h-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">分类分布</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                {statsData.catPie.length === 0 ? (
                  <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">暂无数据</div>
                ) : (
                  <div className="w-full min-w-0 overflow-hidden">
                    <ResponsiveContainer width="100%" height={220}>
                      <PieChart>
                        <Pie data={statsData.catPie} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                          {statsData.catPie.map((_, index) => (
                            <Cell key={index} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value: number, name: string) => [value, name]} />
                        <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8, fontSize: 12 }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* 年度趋势柱状图 */}
            <Card className="h-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">年度归档趋势</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                {statsData.yearBar.length === 0 ? (
                  <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">暂无数据</div>
                ) : (
                  <div className="w-full min-w-0 overflow-hidden">
                    <ResponsiveContainer width="100%" height={220}>
                      <BarChart data={statsData.yearBar} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                        <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                        <YAxis tick={{ fontSize: 12 }} />
                        <Tooltip />
                        <Bar dataKey="value" fill="hsl(180 38% 15%)" name="材料数" radius={[3, 3, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* 奖项等级统计 */}
          {statsData.levelBar.length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">奖项等级分布</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="w-full min-w-0 overflow-hidden">
                  <ResponsiveContainer width="100%" height={160}>
                    <BarChart data={statsData.levelBar} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                      <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Bar dataKey="value" fill="hsl(35 90% 55%)" name="数量" radius={[3, 3, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ── 证件专区 ── */}
        <TabsContent value="cert" className="space-y-4">
          <p className="text-sm text-muted-foreground">证件照独立存储，方便快速调取</p>
          {loading ? (
            <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
              {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="aspect-[3/4] bg-muted rounded" />)}
            </div>
          ) : certAchievements.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <Award className="w-14 h-14 mx-auto mb-3 opacity-20" />
              <p className="text-sm">暂无证件照，上传时选择"个人证件"分类</p>
            </div>
          ) : (
            <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
              {certAchievements.map((a) => (
                <div key={a.id} className="space-y-1">
                  <div
                    className="aspect-[3/4] rounded overflow-hidden bg-muted cursor-pointer relative group"
                    onClick={() => a.image_url && setPreviewImageUrl(a.image_url)}
                  >
                    {a.image_url ? (
                      <img src={a.image_url} alt={a.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ImageIcon className="w-6 h-6 text-muted-foreground" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                      <ZoomIn className="w-5 h-5 text-white" />
                    </div>
                  </div>
                  <p className="text-xs text-center text-muted-foreground truncate">
                    {a.certificate_size === '1inch' ? '一寸' : a.certificate_size === '2inch' ? '两寸' : ''}
                    {a.certificate_bg === 'white' ? '·白底' : a.certificate_bg === 'blue' ? '·蓝底' : a.certificate_bg === 'red' ? '·红底' : ''}
                  </p>
                  <p className="text-xs text-center text-foreground truncate">{a.name}</p>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ── 私密账号专区 ── */}
        <TabsContent value="accounts" className="space-y-4">
          {!accountsUnlocked ? (
            <div className="text-center py-16">
              <Lock className="w-14 h-14 mx-auto mb-4 text-muted-foreground opacity-40" />
              <h3 className="text-base font-semibold mb-2">私密账号专区</h3>
              <p className="text-sm text-muted-foreground mb-4">此区域已加密保护，需验证后方可查看账号密码信息</p>
              <Button onClick={handleUnlockAccounts}>
                <Lock className="w-4 h-4 mr-1.5" />
                解锁查看
              </Button>
            </div>
          ) : accountsLoading ? (
            <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-16 bg-muted" />)}</div>
          ) : accountSecrets.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <Lock className="w-14 h-14 mx-auto mb-3 opacity-20" />
              <p className="text-sm">暂无账号密码，在"资料归档-账号密码"标签页录入</p>
              <Button size="sm" variant="outline" className="mt-3" onClick={() => navigate('/upload')}>
                <Upload className="w-4 h-4 mr-1.5" />去录入
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {accountSecrets.map((secret) => (
                <AccountSecretCard
                  key={secret.id}
                  secret={secret}
                  revealed={revealedIds.has(secret.id)}
                  onToggleReveal={() => setRevealedIds((prev) => {
                    const next = new Set(prev);
                    next.has(secret.id) ? next.delete(secret.id) : next.add(secret.id);
                    return next;
                  })}
                  onDelete={async () => {
                    await supabase.from('account_secrets').delete().eq('id', secret.id);
                    setAccountSecrets((prev) => prev.filter((s) => s.id !== secret.id));
                    toast.success('已删除账号记录');
                  }}
                />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* 详情侧边栏 */}
      <Sheet open={detailOpen} onOpenChange={setDetailOpen}>
        <SheetContent side="right" className="w-full max-w-sm overflow-y-auto bg-background">
          {selectedAchievement && (
            <>
              <SheetHeader className="mb-4">
                <SheetTitle className="text-base text-balance">{selectedAchievement.name}</SheetTitle>
              </SheetHeader>

              {selectedAchievement.file_type === 'image' && selectedAchievement.image_url && (
                <div className="rounded-lg overflow-hidden mb-4 bg-muted cursor-pointer" onClick={() => setPreviewImageUrl(selectedAchievement.image_url)}>
                  <img src={selectedAchievement.image_url} alt={selectedAchievement.name} className="w-full object-cover max-h-48" />
                </div>
              )}

              <div className="space-y-3 text-sm">
                {[
                  { icon: <Tag className="w-4 h-4" />, label: '分类', value: `${getCategoryInfo(selectedAchievement.category)?.icon || ''} ${selectedAchievement.category}${selectedAchievement.subcategory ? ` · ${selectedAchievement.subcategory}` : ''}` },
                  { icon: <Award className="w-4 h-4" />, label: '等级', value: selectedAchievement.level },
                  { icon: <Calendar className="w-4 h-4" />, label: '获得时间', value: selectedAchievement.achieved_at },
                  { icon: <GraduationCap className="w-4 h-4" />, label: '就读年级', value: selectedAchievement.grade_year ? (profile?.education_level ? getGradeLabel(selectedAchievement.grade_year, profile.education_level) : `第${selectedAchievement.grade_year}年`) : null },
                ].filter((r) => r.value).map((row) => (
                  <div key={row.label} className="flex items-start gap-2">
                    <span className="text-muted-foreground mt-0.5 shrink-0">{row.icon}</span>
                    <div>
                      <span className="text-muted-foreground text-xs">{row.label}：</span>
                      <span className="text-foreground">{row.value}</span>
                    </div>
                  </div>
                ))}

                {/* 标签 */}
                {selectedAchievement.tags && selectedAchievement.tags.length > 0 && (
                  <div>
                    <span className="text-xs text-muted-foreground">场景标签：</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {selectedAchievement.tags.map((t) => (
                        <Badge key={t} variant="secondary" className="text-xs">{t}</Badge>
                      ))}
                    </div>
                  </div>
                )}

                {selectedAchievement.notes && (
                  <div>
                    <span className="text-xs text-muted-foreground">备注：</span>
                    <p className="text-foreground text-xs mt-1 text-pretty">{selectedAchievement.notes}</p>
                  </div>
                )}

                {selectedAchievement.ai_description && (
                  <>
                    <Separator />
                    <div>
                      <span className="text-xs text-muted-foreground">AI描述：</span>
                      <p className="text-foreground text-xs mt-1 text-pretty">{selectedAchievement.ai_description}</p>
                    </div>
                  </>
                )}
              </div>

              <Separator className="my-4" />

              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="flex-1" onClick={() => navigate(`/export?ids=${selectedAchievement.id}`)}>
                  <FileDown className="w-4 h-4 mr-1.5" />导出
                </Button>
                <Button size="sm" variant="destructive" onClick={() => { setDeleteTarget(selectedAchievement); }}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>

      {/* 图片全屏预览 */}
      <Dialog open={!!previewImageUrl} onOpenChange={(open) => !open && setPreviewImageUrl(null)}>
        <DialogContent className="max-w-[95vw] max-h-[95vh] p-2 flex items-center justify-center bg-black/90 border-0">
          {previewImageUrl && (
            <img src={previewImageUrl} alt="预览" className="max-w-full max-h-[90vh] object-contain rounded" />
          )}
        </DialogContent>
      </Dialog>

      {/* 删除确认弹窗 */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>删除材料</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除"<strong>{deleteTarget?.name}</strong>"吗？删除后会移入回收站，30天内可恢复。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteTarget && handleDelete(deleteTarget)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              确认删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 批量删除确认 */}
      <AlertDialog open={batchDeleteConfirm} onOpenChange={setBatchDeleteConfirm}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>批量删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除选中的 <strong>{selectedIds.size}</strong> 条材料吗？删除后会移入回收站，30天内可恢复。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleBatchDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              确认删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ────────── 成就卡片 ──────────

interface AchievementCardProps {
  achievement: Achievement;
  batchMode: boolean;
  selected: boolean;
  onSelect: () => void;
  onClick: () => void;
  onPreview: (url: string) => void;
}

function AchievementCard({ achievement, batchMode, selected, onSelect, onClick, onPreview }: AchievementCardProps) {
  const catColor: Record<string, string> = {
    '荣誉奖项': 'bg-[hsl(35_90%_55%/0.12)] text-[hsl(35_80%_35%)] border-[hsl(35_90%_55%/0.3)]',
    '赛事竞赛': 'bg-[hsl(200_80%_45%/0.12)] text-[hsl(200_70%_35%)] border-[hsl(200_80%_45%/0.3)]',
    '志愿实践': 'bg-[hsl(142_70%_40%/0.12)] text-[hsl(142_60%_30%)] border-[hsl(142_70%_40%/0.3)]',
    '学术成果': 'bg-[hsl(280_50%_55%/0.12)] text-[hsl(280_40%_35%)] border-[hsl(280_50%_55%/0.3)]',
    '学生工作': 'bg-[hsl(180_38%_15%/0.08)] text-[hsl(180_38%_25%)] border-[hsl(180_38%_15%/0.2)]',
    '个人证件': 'bg-[hsl(15_80%_50%/0.12)] text-[hsl(15_70%_35%)] border-[hsl(15_80%_50%/0.3)]',
    '其他': 'bg-muted text-muted-foreground border-border',
  };
  const isImage = !achievement.file_type || achievement.file_type === 'image';

  return (
    <Card
      className={cn(
        'achievement-card h-full flex flex-col overflow-hidden border-border cursor-pointer',
        selected && 'ring-2 ring-primary ring-offset-1'
      )}
      onClick={batchMode ? onSelect : onClick}
    >
      {/* 图片区 */}
      <div className="relative aspect-[4/3] bg-muted overflow-hidden shrink-0">
        {isImage && achievement.image_url ? (
          <img src={achievement.image_url} alt={achievement.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center gap-1 text-muted-foreground">
            <span className="text-3xl">{achievement.file_type === 'pdf' ? '📄' : achievement.file_type === 'word' ? '📝' : achievement.file_type === 'excel' ? '📊' : achievement.file_type === 'link' ? '🔗' : '🖼️'}</span>
            <span className="text-xs uppercase">{achievement.file_type}</span>
          </div>
        )}
        {/* 批量选择复选框 */}
        {batchMode && (
          <div className="absolute top-2 left-2">
            <div className={cn('w-5 h-5 rounded border-2 flex items-center justify-center', selected ? 'bg-primary border-primary' : 'bg-white/80 border-border')}>
              {selected && <CheckSquare className="w-3 h-3 text-primary-foreground" />}
            </div>
          </div>
        )}
        {/* 预览按钮 */}
        {!batchMode && isImage && achievement.image_url && (
          <button
            className="absolute top-2 right-2 w-6 h-6 rounded bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 group-hover:opacity-100 transition-opacity"
            onClick={(e) => { e.stopPropagation(); onPreview(achievement.image_url); }}
          >
            <ZoomIn className="w-3 h-3 text-white" />
          </button>
        )}
        {/* 私密标记 */}
        {achievement.is_private && (
          <div className="absolute bottom-2 right-2 w-5 h-5 rounded bg-black/50 flex items-center justify-center">
            <Lock className="w-3 h-3 text-white" />
          </div>
        )}
      </div>

      {/* 信息区 */}
      <CardContent className="p-2.5 flex-1 flex flex-col gap-1.5">
        <p className="text-xs font-medium text-foreground line-clamp-2 text-balance">{achievement.name}</p>
        <div className="flex items-center gap-1 flex-wrap mt-auto">
          <Badge variant="outline" className={cn('text-[10px] py-0 h-4 border', catColor[achievement.category] || catColor['其他'])}>
            {achievement.category}
          </Badge>
          {achievement.level && (
            <Badge variant="secondary" className="text-[10px] py-0 h-4">{achievement.level}</Badge>
          )}
        </div>
        {achievement.achieved_at && (
          <p className="text-[10px] text-muted-foreground">{achievement.achieved_at}</p>
        )}
        {/* 场景标签 */}
        {achievement.tags && achievement.tags.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {achievement.tags.slice(0, 2).map((t) => (
              <span key={t} className="text-[10px] text-muted-foreground bg-muted px-1 rounded">{t}</span>
            ))}
            {achievement.tags.length > 2 && <span className="text-[10px] text-muted-foreground">+{achievement.tags.length - 2}</span>}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ────────── 私密账号卡片 ──────────

interface AccountSecretCardProps {
  secret: AccountSecret;
  revealed: boolean;
  onToggleReveal: () => void;
  onDelete: () => void;
}

function AccountSecretCard({ secret, revealed, onToggleReveal, onDelete }: AccountSecretCardProps) {
  return (
    <Card className="border-border">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0 space-y-2">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-muted-foreground shrink-0" />
              <span className="font-medium text-sm">{secret.platform_name}</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-muted-foreground">账号：</span>
                <span className="text-foreground font-mono">
                  {revealed ? decryptText(secret.username_encrypted) : '••••••••'}
                </span>
              </div>
              <div>
                <span className="text-muted-foreground">密码：</span>
                <span className="text-foreground font-mono">
                  {revealed ? decryptText(secret.password_encrypted) : '••••••••'}
                </span>
              </div>
            </div>
            {secret.notes && <p className="text-xs text-muted-foreground">{secret.notes}</p>}
          </div>
          <div className="flex gap-1 shrink-0">
            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground" onClick={onToggleReveal}>
              {revealed ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive" onClick={onDelete}>
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
