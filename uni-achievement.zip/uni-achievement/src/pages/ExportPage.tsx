import { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import type { Achievement, ShareLink } from '@/types/types';
import { EXPORT_TEMPLATES, ACHIEVEMENT_CATEGORIES } from '@/types/types';
import {
  FileDown,
  Image as ImageIcon,
  Download,
  GripVertical,
  CheckSquare,
  Square,
  Loader2,
  Share2,
  Link2,
  Copy,
  Calendar,
  Lock,
  Award,
  Trash2,
  X,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { HelpTip, TipBanner } from '@/components/common/HelpTip';

// 证件照尺寸（像素，300dpi下）
const CERT_SIZES: Record<string, { w: number; h: number; label: string }> = {
  '1inch': { w: 295, h: 413, label: '一寸（25×35mm）' },
  '2inch': { w: 413, h: 579, label: '两寸（35×49mm）' },
};
const CERT_BACKGROUNDS: Record<string, { label: string; color: string }> = {
  white: { label: '白底', color: '#FFFFFF' },
  blue: { label: '蓝底', color: '#4169E1' },
  red: { label: '红底', color: '#CC1414' },
};

export default function ExportPage() {
  const { user, profile } = useAuth();
  const [searchParams] = useSearchParams();
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [orderedIds, setOrderedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportFormat, setExportFormat] = useState<'pdf' | 'images'>('images');
  const [dragItem, setDragItem] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState<string | null>(null);

  // PDF设置
  const [pdfLayout, setPdfLayout] = useState<'single' | 'multi'>('single');
  const [pdfWatermark, setPdfWatermark] = useState(false);
  const [pdfHeader, setPdfHeader] = useState('');
  const [pdfFooter, setPdfFooter] = useState('');

  // 证件照导出
  const [certSize, setCertSize] = useState<'1inch' | '2inch'>('1inch');
  const [certBg, setCertBg] = useState<'white' | 'blue' | 'red'>('white');
  const [certExporting, setCertExporting] = useState(false);

  // 分享链接
  const [shareLinks, setShareLinks] = useState<ShareLink[]>([]);
  const [shareLinksLoading, setShareLinksLoading] = useState(false);
  const [shareTitle, setShareTitle] = useState('');
  const [shareExpiresDays, setShareExpiresDays] = useState<string>('7');
  const [shareIsPublic, setShareIsPublic] = useState(true);
  const [sharePassword, setSharePassword] = useState('');
  const [creatingShare, setCreatingShare] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);

  // 场景模板
  const [activeTemplate, setActiveTemplate] = useState<string | null>(null);

  const fetchAchievements = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('achievements')
      .select('*')
      .eq('user_id', user.id)
      .order('achieved_at', { ascending: false, nullsFirst: false })
      .order('created_at', { ascending: false });

    if (error) {
      toast.error('加载失败：' + error.message);
    } else {
      const list = Array.isArray(data) ? data : [];
      setAchievements(list);
      const ids = list.map((a) => a.id);
      setOrderedIds(ids);
      const preSelectedId = searchParams.get('ids');
      if (preSelectedId) setSelectedIds(new Set(preSelectedId.split(',')));
    }
    setLoading(false);
  }, [user, searchParams]);

  const fetchShareLinks = useCallback(async () => {
    if (!user) return;
    setShareLinksLoading(true);
    const { data } = await supabase.from('share_links').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(10);
    setShareLinks(Array.isArray(data) ? data : []);
    setShareLinksLoading(false);
  }, [user]);

  useEffect(() => { fetchAchievements(); fetchShareLinks(); }, [fetchAchievements, fetchShareLinks]);

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === achievements.length) setSelectedIds(new Set());
    else setSelectedIds(new Set(achievements.map((a) => a.id)));
  };

  // 应用场景模板
  const applyTemplate = (templateValue: string) => {
    const tpl = EXPORT_TEMPLATES.find((t) => t.value === templateValue);
    if (!tpl) return;
    const matched = achievements.filter((a) => (tpl.categories as readonly string[]).includes(a.category));
    setSelectedIds(new Set(matched.map((a) => a.id)));
    setActiveTemplate(templateValue);
    toast.success(`已选中 ${matched.length} 条"${tpl.label}"相关材料`);
  };

  // 拖拽排序
  const handleDragStart = (id: string) => setDragItem(id);
  const handleDragOver = (id: string) => { if (id !== dragItem) setDragOver(id); };
  const handleDrop = (id: string) => {
    if (!dragItem || dragItem === id) { setDragItem(null); setDragOver(null); return; }
    const from = orderedIds.indexOf(dragItem);
    const to = orderedIds.indexOf(id);
    const newOrder = [...orderedIds];
    newOrder.splice(from, 1);
    newOrder.splice(to, 0, dragItem);
    setOrderedIds(newOrder);
    setDragItem(null); setDragOver(null);
  };

  const selectedAchievements = orderedIds
    .filter((id) => selectedIds.has(id))
    .map((id) => achievements.find((a) => a.id === id)!)
    .filter(Boolean);

  // 图片/PDF导出
  const handleExport = async () => {
    if (selectedAchievements.length === 0) { toast.error('请至少选择一条材料'); return; }
    setExporting(true); setExportProgress(0);

    try {
      if (exportFormat === 'images') {
        const JSZip = (await import('jszip')).default;
        const zip = new JSZip();
        const folder = zip.folder('成就材料导出') || zip;
        for (let i = 0; i < selectedAchievements.length; i++) {
          const a = selectedAchievements[i];
          setExportProgress(Math.round((i / selectedAchievements.length) * 80));
          if (a.image_url) {
            try {
              const resp = await fetch(a.image_url);
              const blob = await resp.blob();
              const ext = a.image_url.split('.').pop()?.split('?')[0] || 'jpg';
              folder.file(`${String(i + 1).padStart(2, '0')}_${a.name.replace(/[/\\?%*:|"<>]/g, '_')}.${ext}`, blob);
            } catch { /* 跳过无法下载的文件 */ }
          }
        }
        setExportProgress(90);
        const blob = await zip.generateAsync({ type: 'blob' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `成就材料_${new Date().toISOString().slice(0, 10)}.zip`;
        link.click();
        URL.revokeObjectURL(url);
        setExportProgress(100);
        toast.success(`已导出 ${selectedAchievements.length} 个材料`);
      } else {
        // PDF导出：先将图片URL转为base64再调用edge function
        const imageAchievements = selectedAchievements.filter((a) => a.image_url);
        if (imageAchievements.length === 0) { toast.error('选中的材料中没有可导出的图片'); setExporting(false); return; }

        // 将图片URL转换为base64
        const images_base64: string[] = [];
        for (let i = 0; i < imageAchievements.length; i++) {
          setExportProgress(Math.round((i / imageAchievements.length) * 40));
          const a = imageAchievements[i];
          try {
            const resp = await fetch(a.image_url!);
            const blob = await resp.blob();
            const base64 = await new Promise<string>((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => resolve((reader.result as string).split(',')[1]);
              reader.onerror = reject;
              reader.readAsDataURL(blob);
            });
            images_base64.push(base64);
          } catch { /* 跳过无法下载的图片 */ }
        }

        if (images_base64.length === 0) { toast.error('图片加载失败，请检查网络后重试'); setExporting(false); return; }

        setExportProgress(50);
        const pollInterval = setInterval(() => {
          setExportProgress((p) => Math.min(p + 3, 85));
        }, 500);

        const { data, error } = await supabase.functions.invoke('export-pdf', {
          body: {
            images_base64,
            layout: pdfLayout,
            watermark: pdfWatermark ? (profile?.name || '') : '',
            header: pdfHeader,
            footer: pdfFooter,
          },
        });

        clearInterval(pollInterval);

        if (error) {
          const errMsg = await error?.context?.text?.();
          throw new Error(errMsg || error.message);
        }

        if (data?.pdf_base64) {
          const byteString = atob(data.pdf_base64);
          const arr = new Uint8Array(byteString.length);
          for (let i = 0; i < byteString.length; i++) arr[i] = byteString.charCodeAt(i);
          const blob = new Blob([arr], { type: 'application/pdf' });
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url; link.download = `成就材料_${new Date().toISOString().slice(0, 10)}.pdf`;
          link.click(); URL.revokeObjectURL(url);
          setExportProgress(100);
          toast.success('PDF已生成并下载');
        } else if (data?.download_url) {
          window.open(data.download_url, '_blank');
          setExportProgress(100);
          toast.success('PDF已生成');
        }
      }
    } catch (err) {
      toast.error('导出失败：' + (err instanceof Error ? err.message : '未知错误'));
    }
    setExporting(false);
    setTimeout(() => setExportProgress(0), 2000);
  };

  // 判断是否是证件照（宽松匹配）
  const isCertPhoto = (a: Achievement) => {
    if (a.category === '个人证件') return true;
    if (a.certificate_size || a.certificate_bg) return true;
    const name = (a.name || '').toLowerCase();
    return name.includes('证件照') || name.includes('一寸') || name.includes('两寸');
  };

  // 证件照导出
  const handleCertExport = async () => {
    const certAchievements = achievements.filter((a) => isCertPhoto(a) && a.image_url);
    const filtered = certAchievements.filter((a) => {
      if (a.certificate_size && a.certificate_size !== certSize) return false;
      if (a.certificate_bg && a.certificate_bg !== certBg) return false;
      return true;
    });

    // 如果精确匹配没有结果，降级为所有证件照
    const exportList = filtered.length > 0 ? filtered : certAchievements;

    if (exportList.length === 0) {
      toast.error('暂无证件照，请先在上传页面归档证件照材料（分类选择个人证件）');
      return;
    }

    setCertExporting(true);
    try {
      const JSZip = (await import('jszip')).default;
      const zip = new JSZip();
      const folder = zip.folder('证件照') || zip;
      const sizeName = certSize === '1inch' ? '一寸' : '两寸';
      const bgName = CERT_BACKGROUNDS[certBg]?.label || certBg;
      let successCount = 0;
      let bgReplaceCount = 0;

      for (let i = 0; i < exportList.length; i++) {
        const a = exportList[i];
        if (!a.image_url) continue;
        try {
          // 获取图片并转为 base64
          const resp = await fetch(a.image_url);
          const blob = await resp.blob();
          const mimeType = blob.type || 'image/jpeg';
          const ext = mimeType.split('/')[1] || 'jpg';
          const safeName = `${sizeName}_${bgName}_${a.name.replace(/[/\\?%*:|"<>]/g, '_')}.${ext}`;

          // 如果导出底色和原始底色不同（或原始底色未知），调用 Gemini 换底色
          const needBgReplace = certBg !== (a.certificate_bg || '') || !a.certificate_bg;
          if (needBgReplace) {
            const base64 = await new Promise<string>((resolve) => {
              const reader = new FileReader();
              reader.onload = () => resolve((reader.result as string).split(',')[1]);
              reader.readAsDataURL(blob);
            });

            try {
              const { supabase: sb } = await import('@/db/supabase');
              const { data: bgData, error: bgError } = await (sb as ReturnType<typeof import('@supabase/supabase-js').createClient>).functions.invoke('replace-cert-bg', {
                body: { image_base64: base64, mime_type: mimeType, target_bg: certBg },
              });

              if (!bgError && bgData?.result_base64) {
                // 使用换底色后的图片
                const byteChars = atob(bgData.result_base64);
                const byteArray = new Uint8Array(byteChars.length);
                for (let j = 0; j < byteChars.length; j++) byteArray[j] = byteChars.charCodeAt(j);
                folder.file(safeName, byteArray, { binary: true });
                bgReplaceCount++;
                successCount++;
                continue;
              }
              // 换底色失败，使用原图
              const errMsg = bgError ? await bgError?.context?.text?.() : null;
              console.warn('换底色失败，使用原图:', errMsg || bgData?.error);
              toast.warning(`${a.name}：换底色失败，已导出原图`);
            } catch (bgErr) {
              console.warn('换底色调用异常，使用原图:', bgErr);
            }
          }

          // 直接使用原图
          folder.file(safeName, blob);
          successCount++;
        } catch { /* 单张失败不阻断整体 */ }
      }

      if (successCount === 0) {
        toast.error('所有证件照导出失败，请检查网络连接后重试');
        return;
      }

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(zipBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `证件照_${sizeName}_${bgName}_${new Date().toISOString().slice(0, 10)}.zip`;
      link.click();
      URL.revokeObjectURL(url);

      const msg = bgReplaceCount > 0
        ? `已导出 ${successCount} 张，其中 ${bgReplaceCount} 张成功换底色为${bgName}`
        : `已导出 ${successCount} 张证件照`;
      toast.success(msg);
    } catch (err) {
      toast.error(`导出失败：${err instanceof Error ? err.message : '请稍后重试'}`);
    }
    setCertExporting(false);
  };

  // 创建分享链接
  const createShareLink = async () => {
    if (selectedIds.size === 0) { toast.error('请先选择要分享的材料'); return; }
    setCreatingShare(true);
    try {
      const expiresAt = shareExpiresDays !== 'never'
        ? new Date(Date.now() + Number(shareExpiresDays) * 86400000).toISOString()
        : null;
      const { data, error } = await supabase.from('share_links').insert({
        user_id: user!.id,
        title: shareTitle || '我的成就档案',
        achievement_ids: [...selectedIds],
        is_public: shareIsPublic,
        password: sharePassword || null,
        expires_at: expiresAt,
      }).select().maybeSingle();

      if (error) throw error;
      if (data) {
        setShareLinks((prev) => [data, ...prev]);
        toast.success('分享链接已创建');
        setShareDialogOpen(false);
        setShareTitle(''); setSharePassword(''); setShareExpiresDays('7');
      }
    } catch (err) {
      toast.error('创建失败：' + (err instanceof Error ? err.message : '未知错误'));
    }
    setCreatingShare(false);
  };

  const copyShareLink = (id: string) => {
    const url = `${window.location.origin}/share/${id}`;
    navigator.clipboard.writeText(url).then(() => toast.success('链接已复制到剪贴板'));
  };

  const deleteShareLink = async (id: string) => {
    await supabase.from('share_links').delete().eq('id', id);
    setShareLinks((prev) => prev.filter((l) => l.id !== id));
    toast.success('分享链接已删除');
  };

  const certAchievementsCount = achievements.filter((a) => {
    if (!a.image_url) return false;
    if (!isCertPhoto(a)) return false;
    if (a.certificate_size && a.certificate_size !== certSize) return false;
    if (a.certificate_bg && a.certificate_bg !== certBg) return false;
    return true;
  }).length;
  const totalCertCount = achievements.filter((a) => isCertPhoto(a) && a.image_url).length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-foreground text-balance">导出与分享</h1>
        <p className="text-sm text-muted-foreground mt-1 text-pretty">选择材料，选择场景模板，生成导出包或分享链接</p>
      </div>

      <TipBanner>
        <strong>使用说明：</strong>
        <span className="ml-1">「材料导出」选中材料后点击导出PDF/图片压缩包；「证件照导出」支持自动换底色（AI将蓝底/红底换为白底等）；「分享链接」生成带有效期的在线访问链接。</span>
      </TipBanner>

      <Tabs defaultValue="export">
        <TabsList>
          <TabsTrigger value="export"><Download className="w-4 h-4 mr-1.5" />材料导出</TabsTrigger>
          <TabsTrigger value="cert"><Award className="w-4 h-4 mr-1.5" />证件照导出</TabsTrigger>
          <TabsTrigger value="share"><Share2 className="w-4 h-4 mr-1.5" />分享链接</TabsTrigger>
        </TabsList>

        {/* ── 材料导出 ── */}
        <TabsContent value="export" className="space-y-4 mt-4">
          {/* 场景模板 */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">场景模板快选</CardTitle>
              <CardDescription className="text-xs">选择场景模板，自动匹配对应材料</CardDescription>
            </CardHeader>
            <CardContent className="p-4 pt-0">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {EXPORT_TEMPLATES.map((tpl) => (
                  <button
                    key={tpl.value}
                    onClick={() => applyTemplate(tpl.value)}
                    className={cn(
                      'flex flex-col items-center gap-1 p-3 rounded-lg border text-center transition-colors text-sm',
                      activeTemplate === tpl.value
                        ? 'border-primary bg-primary/5 text-primary'
                        : 'border-border hover:border-primary/50 hover:bg-muted/30'
                    )}
                  >
                    <span className="text-xl">{tpl.icon}</span>
                    <span className="text-xs font-medium text-balance">{tpl.label}</span>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* 材料选择列表 */}
            <div className="md:col-span-2 space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-medium">选择材料</h2>
                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={toggleSelectAll}>
                  {selectedIds.size === achievements.length && achievements.length > 0 ? (
                    <><CheckSquare className="w-3 h-3 mr-1" />取消全选</>
                  ) : (
                    <><Square className="w-3 h-3 mr-1" />全选</>
                  )}
                </Button>
              </div>

              {loading ? (
                <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-14 bg-muted rounded animate-pulse" />)}</div>
              ) : achievements.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground text-sm">暂无材料，请先上传归档</div>
              ) : (
                <div className="space-y-1.5 max-h-[60vh] overflow-y-auto pr-1">
                  {orderedIds.map((id) => {
                    const a = achievements.find((x) => x.id === id);
                    if (!a) return null;
                    return (
                      <div
                        key={id}
                        draggable
                        onDragStart={() => handleDragStart(id)}
                        onDragOver={(e) => { e.preventDefault(); handleDragOver(id); }}
                        onDrop={() => handleDrop(id)}
                        className={cn(
                          'flex items-center gap-2 p-2 rounded-lg border cursor-grab active:cursor-grabbing transition-colors',
                          selectedIds.has(id) ? 'border-primary/40 bg-primary/5' : 'border-border hover:bg-muted/30',
                          dragOver === id && 'border-primary border-dashed bg-primary/10'
                        )}
                      >
                        <GripVertical className="w-4 h-4 text-muted-foreground shrink-0" />
                        <Checkbox checked={selectedIds.has(id)} onCheckedChange={() => toggleSelect(id)} />
                        <div className="w-8 h-8 rounded overflow-hidden bg-muted shrink-0 flex items-center justify-center">
                          {a.file_type === 'image' && a.image_url ? (
                            <img src={a.image_url} alt={a.name} className="w-full h-full object-cover" />
                          ) : (
                            <span className="text-xs">{a.file_type === 'pdf' ? '📄' : a.file_type === 'link' ? '🔗' : '📝'}</span>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium truncate">{a.name}</p>
                          <p className="text-[10px] text-muted-foreground">{a.category}{a.achieved_at ? ` · ${a.achieved_at}` : ''}</p>
                        </div>
                        {a.level && <Badge variant="outline" className="text-[10px] shrink-0">{a.level}</Badge>}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* 导出设置面板 */}
            <div className="space-y-3">
              <h2 className="text-sm font-medium">导出设置</h2>
              <Card>
                <CardContent className="p-4 space-y-4">
                  <div className="space-y-2">
                    <Label className="text-xs font-normal text-muted-foreground">导出格式</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { value: 'images', label: '图片压缩包', icon: '🖼️' },
                        { value: 'pdf', label: 'PDF文件', icon: '📄' },
                      ].map((opt) => (
                        <button
                          key={opt.value}
                          onClick={() => setExportFormat(opt.value as 'images' | 'pdf')}
                          className={cn(
                            'flex flex-col items-center gap-1 p-3 rounded-lg border text-xs transition-colors',
                            exportFormat === opt.value ? 'border-primary bg-primary/5 text-primary' : 'border-border hover:bg-muted/30'
                          )}
                        >
                          <span className="text-lg">{opt.icon}</span>
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {exportFormat === 'pdf' && (
                    <>
                      <Separator />
                      <div className="space-y-3">
                        <div className="space-y-1">
                          <Label className="text-xs font-normal text-muted-foreground">PDF排版</Label>
                          <Select value={pdfLayout} onValueChange={(v) => setPdfLayout(v as 'single' | 'multi')}>
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="single">一页一图</SelectItem>
                              <SelectItem value="multi">一页多图</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-normal text-muted-foreground">页眉</Label>
                          <Input value={pdfHeader} onChange={(e) => setPdfHeader(e.target.value)} placeholder="如：个人成就材料汇编" className="h-8 text-xs" />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-normal text-muted-foreground">页脚</Label>
                          <Input value={pdfFooter} onChange={(e) => setPdfFooter(e.target.value)} placeholder="如：姓名/学校/学号" className="h-8 text-xs" />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label className="text-xs font-normal text-muted-foreground">个人信息水印</Label>
                          <Switch checked={pdfWatermark} onCheckedChange={setPdfWatermark} />
                        </div>
                      </div>
                    </>
                  )}

                  <Separator />

                  <div className="text-xs text-muted-foreground">
                    已选 <span className="font-semibold text-foreground">{selectedIds.size}</span> / {achievements.length} 条材料
                  </div>

                  {exporting && (
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>导出中...</span><span>{exportProgress}%</span>
                      </div>
                      <Progress value={exportProgress} className="h-1.5" />
                    </div>
                  )}

                  <Button className="w-full" disabled={selectedIds.size === 0 || exporting} onClick={handleExport}>
                    {exporting ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : <FileDown className="w-4 h-4 mr-1.5" />}
                    {exporting ? '导出中...' : `导出 ${selectedIds.size > 0 ? `(${selectedIds.size})` : ''}`}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* ── 证件照导出 ── */}
        <TabsContent value="cert" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <CardTitle className="text-sm">证件照参数设置</CardTitle>
                  <HelpTip
                    content="选择目标尺寸和底色后，系统会调用AI自动将证件照换底色（如蓝底→白底）后再导出。换底色由AI处理，请使用清晰正面照以获得最佳效果。"
                    side="right"
                    maxWidth="260px"
                  />
                </div>
                <CardDescription className="text-xs">选择尺寸和底色，AI自动换底色后导出标准证件照</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-xs font-normal text-muted-foreground">证件照尺寸</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {Object.entries(CERT_SIZES).map(([key, val]) => (
                      <button
                        key={key}
                        onClick={() => setCertSize(key as '1inch' | '2inch')}
                        className={cn(
                          'flex flex-col items-center gap-1 p-3 rounded-lg border text-xs transition-colors',
                          certSize === key ? 'border-primary bg-primary/5 text-primary' : 'border-border hover:bg-muted/30'
                        )}
                      >
                        <span className="text-lg">🪪</span>
                        {val.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs font-normal text-muted-foreground">底色</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {Object.entries(CERT_BACKGROUNDS).map(([key, val]) => (
                      <button
                        key={key}
                        onClick={() => setCertBg(key as 'white' | 'blue' | 'red')}
                        className={cn(
                          'flex flex-col items-center gap-1.5 p-3 rounded-lg border text-xs transition-colors',
                          certBg === key ? 'border-primary ring-1 ring-primary' : 'border-border hover:bg-muted/30'
                        )}
                      >
                        <div className="w-8 h-8 rounded border border-border" style={{ backgroundColor: val.color }} />
                        {val.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground">
                  当前设置精确匹配 <strong className="text-foreground">{certAchievementsCount}</strong> 张，共归档 <strong className="text-foreground">{totalCertCount}</strong> 张证件照
                </div>

                <Button className="w-full" disabled={totalCertCount === 0 || certExporting} onClick={handleCertExport}>
                  {certExporting ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : <Download className="w-4 h-4 mr-1.5" />}
                  {certExporting ? '导出中...' : `导出证件照 (${certAchievementsCount > 0 ? certAchievementsCount : totalCertCount}张)`}
                </Button>
              </CardContent>
            </Card>

            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">使用场景</CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="space-y-2 text-xs text-muted-foreground">
                    {['学籍报名、入学注册', '考试报名（四六级、考研）', '简历投递、求职应聘', '证件办理（学生证、奖学金申请）', '研究生复试、保研材料'].map((s) => (
                      <div key={s} className="flex items-center gap-2">
                        <span className="text-primary">✓</span>
                        <span>{s}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* ── 分享链接 ── */}
        <TabsContent value="share" className="space-y-4 mt-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-medium">我的分享链接</h2>
              <p className="text-xs text-muted-foreground mt-0.5">生成个人成就档案链接，方便求职/复试展示</p>
            </div>
            <Button size="sm" onClick={() => setShareDialogOpen(true)}>
              <Share2 className="w-4 h-4 mr-1.5" />
              创建分享链接
            </Button>
          </div>

          {shareLinksLoading ? (
            <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-16 bg-muted rounded animate-pulse" />)}</div>
          ) : shareLinks.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Link2 className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p className="text-sm">暂无分享链接，点击"创建分享链接"生成</p>
            </div>
          ) : (
            <div className="space-y-3">
              {shareLinks.map((link) => (
                <Card key={link.id} className="border-border">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium truncate">{link.title}</p>
                          {link.password && <Lock className="w-3 h-3 text-muted-foreground shrink-0" />}
                        </div>
                        <p className="text-xs text-muted-foreground font-mono truncate">
                          {window.location.origin}/share/{link.id}
                        </p>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span>{link.achievement_ids?.length ?? 0} 条材料</span>
                          <span>{link.access_count} 次访问</span>
                          {link.expires_at && (
                            <span className={new Date(link.expires_at) < new Date() ? 'text-destructive' : ''}>
                              {new Date(link.expires_at) < new Date() ? '已过期' : `过期：${link.expires_at.slice(0, 10)}`}
                            </span>
                          )}
                          {!link.expires_at && <span>永久有效</span>}
                        </div>
                      </div>
                      <div className="flex gap-1 shrink-0">
                        <Button size="sm" variant="outline" className="h-7 text-xs px-2" onClick={() => copyShareLink(link.id)}>
                          <Copy className="w-3 h-3 mr-1" />复制
                        </Button>
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive" onClick={() => deleteShareLink(link.id)}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* 创建分享链接弹窗 */}
      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle>创建分享链接</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground">
              当前已选 <strong className="text-foreground">{selectedIds.size}</strong> 条材料将包含在分享链接中。
              {selectedIds.size === 0 && <span className="text-destructive ml-1">请先在材料导出标签中选择材料</span>}
            </div>

            <div className="space-y-1">
              <Label className="text-xs font-normal text-muted-foreground">链接标题</Label>
              <Input value={shareTitle} onChange={(e) => setShareTitle(e.target.value)} placeholder="我的成就档案" className="text-sm" />
            </div>

            <div className="space-y-1">
              <Label className="text-xs font-normal text-muted-foreground">有效期</Label>
              <Select value={shareExpiresDays} onValueChange={setShareExpiresDays}>
                <SelectTrigger className="text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1天</SelectItem>
                  <SelectItem value="7">7天</SelectItem>
                  <SelectItem value="30">30天</SelectItem>
                  <SelectItem value="never">永久有效</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label className="text-xs font-normal">公开访问</Label>
                <p className="text-xs text-muted-foreground mt-0.5">任何有链接的人均可查看</p>
              </div>
              <Switch checked={shareIsPublic} onCheckedChange={setShareIsPublic} />
            </div>

            <div className="space-y-1">
              <Label className="text-xs font-normal text-muted-foreground">访问密码（可选）</Label>
              <Input
                type="password"
                value={sharePassword}
                onChange={(e) => setSharePassword(e.target.value)}
                placeholder="留空则无需密码"
                className="text-sm"
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShareDialogOpen(false)}>取消</Button>
              <Button onClick={createShareLink} disabled={creatingShare || selectedIds.size === 0}>
                {creatingShare ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : <Share2 className="w-4 h-4 mr-1.5" />}
                {creatingShare ? '创建中...' : '创建链接'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
